import json
import mimetypes
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path

from .errors import BulkPicConvError


DEFAULT_BASE_URL = "https://www.bulkpicconv.com"
RETRYABLE_STATUSES = {408, 429, 500, 502, 503, 504}


class BulkPicConv:
    def __init__(self, api_key, *, base_url=DEFAULT_BASE_URL, timeout=30, max_retries=2, retry_delay=0.25):
        if not api_key:
            raise ValueError("BulkPicConv: api_key is required")
        self.api_key = api_key
        self.base_url = str(base_url).rstrip("/")
        self.timeout = max(0, float(timeout))
        self.max_retries = max(0, min(5, int(max_retries)))
        self.retry_delay = max(0, float(retry_delay))

    def convert(self, image, options=None):
        return self._image_request("/api/v1/convert", image, options or {})

    def resize(self, image, options=None):
        return self._image_request("/api/v1/resize", image, options or {})

    def crop(self, image, options=None):
        return self._image_request("/api/v1/crop", image, options or {})

    def optimize(self, image, options=None):
        return self._image_request("/api/v1/optimize", image, options or {})

    def watermark(self, image, watermark, options=None):
        options = dict(options or {})
        source = self._read_image(image, options.pop("filename", "image.jpg"))
        mark = self._read_image(watermark, options.pop("watermark_filename", "watermark.png"))
        return self._multipart_request(
            "/api/v1/watermark",
            [("image", source), ("watermark", mark)],
            options,
            binary=True,
        )

    def create_batch(self, archive, options=None):
        options = dict(options or {})
        filename = options.pop("filename", "images.zip")
        source = self._read_image(archive, filename)
        return self._multipart_request(
            "/api/v2/batch",
            [("file", source)],
            options,
            binary=False,
        )["data"]

    def get_batch_status(self, job_id):
        return self._request(f"/api/v2/batch/{urllib.parse.quote(str(job_id), safe='')}/status")["data"]

    def download_batch_result(self, job_id):
        return self._request(
            f"/api/v2/batch/{urllib.parse.quote(str(job_id), safe='')}/result",
            binary=True,
        )

    def get_usage(self):
        return self._request("/api/v2/usage")["data"]

    def get_credits(self):
        return self._request("/api/v2/credits")["data"]

    # ── AI Methods ──────────────────────────────────────────────

    def ai_alt_text(self, images, options=None):
        return self._ai_request("/v1/ai/alt-text", images, options or {})

    def ai_rename(self, images, options=None):
        return self._ai_request("/v1/ai/rename", images, options or {})

    def ai_smart_crop(self, image, options=None):
        return self._ai_request("/v1/ai/smart-crop", [image], options or {})

    def ai_enhance(self, image, options=None):
        return self._ai_request("/v1/ai/enhance", [image], options or {})

    def ai_recommend(self, images, options=None):
        return self._ai_request("/v1/ai/recommend", images, options or {})

    def background_remove(self, image, options=None):
        options = dict(options or {})
        source = self._read_image(image, options.pop("filename", "image.png"))
        return self._multipart_request(
            "/api/background-remove",
            [("image", source)],
            options,
            binary=True,
        )

    def _ai_request(self, path, images, options):
        options = dict(options or {})
        body = {"images": images, **options}
        return self._json_post_request(path, body)["data"]

    def _json_post_request(self, path, body):
        data = json.dumps(body).encode("utf-8")
        return self._request(
            path,
            method="POST",
            data=data,
            headers={"Content-Type": "application/json"},
            binary=False,
        )

    def convert_file(self, input_path, output_path, options=None):
        result = self.convert(input_path, options)
        Path(output_path).write_bytes(result["buffer"])
        return {key: result[key] for key in ("output_size", "input_size", "saved_percent")}

    def _image_request(self, path, image, options):
        options = dict(options or {})
        source = self._read_image(image, options.pop("filename", "image.jpg"))
        return self._multipart_request(path, [("image", source)], options, binary=True)

    @staticmethod
    def _read_image(image, fallback_filename):
        if isinstance(image, (str, os.PathLike)):
            path = Path(image)
            return {"data": path.read_bytes(), "filename": path.name, "content_type": mimetypes.guess_type(path.name)[0] or "application/octet-stream"}
        if isinstance(image, bytes):
            return {"data": image, "filename": fallback_filename, "content_type": mimetypes.guess_type(fallback_filename)[0] or "application/octet-stream"}
        raise TypeError("BulkPicConv: image must be bytes or a file path")

    @staticmethod
    def _multipart(fields, files):
        boundary = uuid.uuid4().hex
        chunks = []
        for name, value in fields.items():
            chunks.extend([
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
                str(value).encode(),
                b"\r\n",
            ])
        for name, file in files:
            chunks.extend([
                f"--{boundary}\r\n".encode(),
                f'Content-Disposition: form-data; name="{name}"; filename="{file["filename"]}"\r\n'.encode(),
                f'Content-Type: {file["content_type"]}\r\n\r\n'.encode(),
                file["data"],
                b"\r\n",
            ])
        chunks.append(f"--{boundary}--\r\n".encode())
        return boundary, b"".join(chunks)

    def _multipart_request(self, path, files, fields, *, binary):
        boundary, body = self._multipart(fields, files)
        return self._request(
            path,
            method="POST",
            data=body,
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
            binary=binary,
        )

    def _request(self, path, *, method="GET", data=None, headers=None, binary=False):
        request_headers = {"Authorization": f"Bearer {self.api_key}"}
        request_headers.update(headers or {})
        request = urllib.request.Request(
            f"{self.base_url}{path}", data=data, headers=request_headers, method=method
        )
        attempt = 0
        while True:
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    response_headers = {key.lower(): value for key, value in response.headers.items()}
                    payload = response.read()
                    if binary:
                        return {
                            "buffer": payload,
                            "output_size": int(response_headers.get("x-output-size", len(payload))),
                            "input_size": int(response_headers.get("x-input-size", 0)),
                            "saved_percent": int(response_headers.get("x-saved-percent", 0)),
                            "headers": response_headers,
                        }
                    return {"data": json.loads(payload.decode("utf-8")), "headers": response_headers}
            except urllib.error.HTTPError as error:
                response_headers = {key.lower(): value for key, value in error.headers.items()}
                details = self._read_json(error)
                code = details.get("error", details.get("code", f"http_{error.code}")) if details else f"http_{error.code}"
                if error.code in RETRYABLE_STATUSES and attempt < self.max_retries:
                    self._sleep(attempt, response_headers.get("retry-after"))
                    attempt += 1
                    continue
                raise BulkPicConvError(
                    f"BulkPicConv API error ({error.code}): {code}",
                    status=error.code,
                    code=code,
                    details=details,
                    retry_after=response_headers.get("retry-after"),
                ) from error
            except (urllib.error.URLError, TimeoutError, OSError) as error:
                if attempt < self.max_retries:
                    self._sleep(attempt, None)
                    attempt += 1
                    continue
                raise BulkPicConvError(f"BulkPicConv: network error - {error}", details=error) from error

    @staticmethod
    def _read_json(error):
        try:
            return json.loads(error.read().decode("utf-8"))
        except (ValueError, UnicodeDecodeError, OSError):
            return None

    def _sleep(self, attempt, retry_after):
        delay = self.retry_delay * (2**attempt)
        if retry_after:
            try:
                delay = max(delay, float(retry_after))
            except ValueError:
                pass
        if delay:
            time.sleep(delay)
