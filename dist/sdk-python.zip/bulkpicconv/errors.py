class BulkPicConvError(Exception):
    """Error raised by the BulkPicConv API or client transport."""

    def __init__(self, message, *, status=0, code="network_error", details=None, retry_after=None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details
        self.retry_after = retry_after
