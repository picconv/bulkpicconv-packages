from bulkpicconv import BulkPicConv, BulkPicConvError

client = BulkPicConv("sk_your_api_key", timeout=30, max_retries=2)

try:
    result = client.convert_file("photo.jpg", "photo.webp", {"format": "webp", "quality": 80})
    print(f"Saved {result['saved_percent']}%")
except BulkPicConvError as error:
    print(error.code, error.status)
