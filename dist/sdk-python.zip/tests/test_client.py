import json
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from io import BytesIO

from bulkpicconv import BulkPicConv, BulkPicConvError


class FakeHeaders(dict):
    def items(self):
        return super().items()


class FakeResponse:
    def __init__(self, body, headers=None):
        self.body = body
        self.headers = FakeHeaders(headers or {})

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return self.body


class ClientTests(unittest.TestCase):
    def test_convert_bytes_builds_multipart_and_returns_metadata(self):
        response = FakeResponse(b"output", {"Content-Type": "image/webp", "X-Input-Size": "10", "X-Output-Size": "7", "X-Saved-Percent": "30"})
        with patch("urllib.request.urlopen", return_value=response) as urlopen:
            result = BulkPicConv("sk_test", retry_delay=0).convert(b"input", {"format": "webp", "quality": 80})
        request = urlopen.call_args.args[0]
        self.assertEqual(request.full_url, "https://www.bulkpicconv.com/api/v1/convert")
        self.assertEqual(request.get_header("Authorization"), "Bearer sk_test")
        self.assertIn(b'name="format"', request.data)
        self.assertIn(b"webp", request.data)
        self.assertEqual(result["buffer"], b"output")
        self.assertEqual(result["saved_percent"], 30)

    def test_retries_transient_http_error(self):
        error = HTTPError("http://example", 503, "temporary", FakeHeaders(), BytesIO(b'{"error":"temporary"}'))
        with patch("urllib.request.urlopen", side_effect=[error, FakeResponse(b"output")]) as urlopen:
            result = BulkPicConv("sk_test", retry_delay=0, max_retries=1).convert(b"input")
        self.assertEqual(result["buffer"], b"output")
        self.assertEqual(urlopen.call_count, 2)

    def test_does_not_retry_bad_request(self):
        error = HTTPError("http://example", 400, "bad", FakeHeaders(), BytesIO(b'{"error":"invalid_params"}'))
        with patch("urllib.request.urlopen", side_effect=error) as urlopen:
            with self.assertRaises(BulkPicConvError) as raised:
                BulkPicConv("sk_test", retry_delay=0, max_retries=2).convert(b"input")
        self.assertEqual(raised.exception.status, 400)
        self.assertEqual(raised.exception.code, "invalid_params")
        self.assertEqual(urlopen.call_count, 1)

    def test_batch_status_uses_encoded_job_id(self):
        response = FakeResponse(b'{"status":"completed"}', {"Content-Type": "application/json"})
        with patch("urllib.request.urlopen", return_value=response) as urlopen:
            result = BulkPicConv("sk_test").get_batch_status("job/1")
        self.assertEqual(result["status"], "completed")
        self.assertIn("job%2F1", urlopen.call_args.args[0].full_url)


if __name__ == "__main__":
    unittest.main()
