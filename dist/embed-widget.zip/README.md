# BulkPicConv Embed Widget

Embeddable image conversion widget for any website. Includes a JavaScript SDK for easy integration.

## Quick Start

```html
<!-- 1. Load the SDK -->
<script src="https://www.bulkpicconv.com/sdk/bic-embed.js"></script>

<!-- 2. Add a target container -->
<div id="converter"></div>

<!-- 3. Initialize -->
<script>
  BICEmbed.init('#converter', {
    format: 'webp',
    quality: 80,
    brand: 'My Brand',
  })
</script>
```

## SDK API

### `BICEmbed.init(target, options)`

Mount the embed widget into a container element.

**Parameters:**

| Parameter              | Type                | Required | Default                             | Description                                   |
| ---------------------- | ------------------- | -------- | ----------------------------------- | --------------------------------------------- |
| `target`               | `string \| Element` | Yes      | —                                   | CSS selector or DOM element                   |
| `options.format`       | `string`            | No       | `webp`                              | Default format: `webp`, `avif`, `jpeg`, `png` |
| `options.quality`      | `number`            | No       | `80`                                | Default quality 1–100                         |
| `options.brand`        | `string`            | No       | —                                   | Brand name displayed in header                |
| `options.hideHeader`   | `boolean`           | No       | `false`                             | Hide the header bar                           |
| `options.hideBranding` | `boolean`           | No       | `false`                             | Hide "Powered by" text (requires Pro)         |
| `options.baseUrl`      | `string`            | No       | `https://www.bulkpicconv.com/embed` | Custom embed URL                              |
| `options.height`       | `number`            | No       | `500`                               | Iframe height in pixels                       |
| `options.apiKey`       | `string`            | No       | —                                   | Pre-fill API key                              |
| `options.onComplete`   | `Function`          | No       | —                                   | Callback when conversion completes            |
| `options.onAiComplete` | `Function`          | No       | —                                   | Callback when AI tool processing completes    |

**Returns:** `{ iframe, postMessage(data), destroy() }`

### `BICEmbed.createButton(target, options)`

Create a button that opens the converter in a modal dialog.

```js
BICEmbed.createButton('#convert-btn', {
  format: 'avif',
  quality: 75,
  onComplete: (data) => console.log(`Converted ${data.count} images`),
})
```

## AI Tools

The embed widget includes AI-powered image tools. After uploading images, users can expand the **AI Tools** section to access:

| Tool          | Description                                       |
| ------------- | ------------------------------------------------- |
| **Alt Text**  | Generate descriptive alt text for images using AI |
| **Remove BG** | Remove image background, returns transparent PNG  |
| **Enhance**   | AI-enhance image quality                          |

### AI Callback

```js
BICEmbed.init('#converter', {
  onAiComplete: (data) => {
    console.log(`AI tool "${data.tool}" processed ${data.count} images`)
  },
})
```

## URL Parameters

The iframe URL supports these query parameters:

| Parameter      | Description           |
| -------------- | --------------------- |
| `format`       | Default output format |
| `quality`      | Default quality       |
| `brand`        | Brand name            |
| `hideHeader`   | `1` to hide header    |
| `hideBranding` | `1` to hide branding  |
| `dark`         | `1` for dark mode     |

## PostMessage Events

### From parent → iframe

```js
// Send configuration
iframe.contentWindow.postMessage(
  {
    type: 'bic-embed-config',
    format: 'webp',
    quality: 80,
  },
  '*',
)
```

### From iframe → parent

```js
window.addEventListener('message', (e) => {
  if (e.data.type === 'bic-embed-complete') {
    console.log('Converted:', e.data.count, 'images')
  }
  if (e.data.type === 'bpc-embed-ai-complete') {
    console.log('AI tool:', e.data.tool, 'processed:', e.data.count)
  }
})
```

## Requirements

- A BulkPicConv account (free tier available)
- AI tools require a Pro subscription

## Browser Support

All modern browsers that support `<iframe>` and `postMessage`.

## License

Part of [BulkPicConv](https://www.bulkpicconv.com).
