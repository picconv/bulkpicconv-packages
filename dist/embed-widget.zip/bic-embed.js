/**
 * BulkPicConv - Embed SDK
 *
 * Usage:
 *   <script src="https://www.bulkpicconv.com/sdk/bic-embed.js"></script>
 *   <div id="bic-embed"></div>
 *   <script>
 *     BICEmbed.init('#bic-embed', { format: 'webp', quality: 80 });
 *   </script>
 */
;(function () {
  'use strict'

  var DEFAULT_URL = 'https://www.bulkpicconv.com/embed'
  var DEFAULT_HEIGHT = 500

  var BICEmbed = {
    /**
     * Initialize the embed widget
     * @param {string|Element} target - CSS selector or DOM element
     * @param {Object} options - Configuration options
     * @param {string} options.format - Default format (webp|avif|jpeg|png)
     * @param {number} options.quality - Default quality (1-100)
     * @param {string} options.brand - Brand name to display
     * @param {boolean} options.hideHeader - Hide the header
     * @param {boolean} options.hideBranding - Hide "Powered by" text
     * @param {string} options.baseUrl - Custom base URL for the embed
     * @param {number} options.height - Iframe height in pixels
     * @param {Function} options.onComplete - Callback when conversion completes
     * @param {Function} options.onAiComplete - Callback when AI tool processing completes
     */
    init: function (target, options) {
      options = options || {}

      var container = typeof target === 'string' ? document.querySelector(target) : target
      if (!container) {
        console.error('BICEmbed: Target element not found')
        return
      }

      // Build iframe URL
      var baseUrl = options.baseUrl || DEFAULT_URL
      var params = new URLSearchParams()

      if (options.format) params.set('format', options.format)
      if (options.quality) params.set('quality', options.quality)
      if (options.brand) params.set('brand', options.brand)
      if (options.hideHeader) params.set('hideHeader', '1')
      if (options.hideBranding) params.set('hideBranding', '1')
      if (options.apiKey) params.set('apiKey', options.apiKey)

      var iframeUrl = baseUrl + '?' + params.toString()

      // Create iframe
      var iframe = document.createElement('iframe')
      iframe.src = iframeUrl
      iframe.style.width = '100%'
      iframe.style.height = (options.height || DEFAULT_HEIGHT) + 'px'
      iframe.style.border = 'none'
      iframe.style.borderRadius = '12px'
      iframe.style.overflow = 'hidden'
      iframe.setAttribute('loading', 'lazy')
      iframe.setAttribute('allow', 'clipboard-write')

      container.appendChild(iframe)

      // Listen for messages from iframe
      window.addEventListener('message', function (e) {
        if (e.data && e.data.type === 'bic-embed-complete') {
          if (typeof options.onComplete === 'function') {
            options.onComplete({
              count: e.data.count,
            })
          }
        }
        if (e.data && e.data.type === 'bpc-embed-ai-complete') {
          if (typeof options.onAiComplete === 'function') {
            options.onAiComplete({
              tool: e.data.tool,
              count: e.data.count,
            })
          }
        }
      })

      // Send config to iframe when ready
      iframe.addEventListener('load', function () {
        iframe.contentWindow.postMessage(
          {
            type: 'bic-embed-config',
            format: options.format,
            quality: options.quality,
          },
          '*',
        )
      })

      // Return API object
      return {
        iframe: iframe,
        postMessage: function (data) {
          iframe.contentWindow.postMessage(data, '*')
        },
        destroy: function () {
          container.removeChild(iframe)
        },
      }
    },

    /**
     * Create a simple "Convert Image" button that opens the converter
     * @param {string|Element} target - CSS selector or DOM element
     * @param {Object} options - Same options as init()
     */
    createButton: function (target, options) {
      options = options || {}

      var btn = typeof target === 'string' ? document.querySelector(target) : target
      if (!btn) {
        console.error('BICEmbed: Button element not found')
        return
      }

      var modal = null
      var widget = null

      btn.addEventListener('click', function () {
        // Create modal
        modal = document.createElement('div')
        modal.style.cssText =
          'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;padding:20px;'

        var content = document.createElement('div')
        content.style.cssText =
          'background:white;border-radius:16px;max-width:640px;width:100%;max-height:90vh;overflow:auto;position:relative;'

        var closeBtn = document.createElement('button')
        closeBtn.textContent = '\u00D7'
        closeBtn.style.cssText =
          'position:absolute;top:8px;right:12px;background:none;border:none;font-size:24px;cursor:pointer;color:#64748b;z-index:1;'
        closeBtn.onclick = function () {
          document.body.removeChild(modal)
          if (widget) widget.destroy()
          modal = null
          widget = null
        }

        var embedTarget = document.createElement('div')
        content.appendChild(closeBtn)
        content.appendChild(embedTarget)
        modal.appendChild(content)
        document.body.appendChild(modal)

        // Close on backdrop click
        modal.addEventListener('click', function (e) {
          if (e.target === modal) {
            closeBtn.click()
          }
        })

        // Initialize embed
        widget = BICEmbed.init(embedTarget, options)
      })
    },
  }

  // Export
  if (typeof window !== 'undefined') {
    window.BICEmbed = BICEmbed
  }
})()
