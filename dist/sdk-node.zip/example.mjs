/**
 * BulkPicConv SDK - Example Usage
 *
 * Run with:
 *   BULKPICCONV_API_KEY=sk_xxx node example.mjs
 *
 * Or set the key inline below.
 */

import { BulkPicConv } from './index.js'
import { writeFile } from 'node:fs/promises'

const apiKey = process.env.BULKPICCONV_API_KEY || 'sk_your_api_key'

const client = new BulkPicConv({
  apiKey,
  timeout: 30_000,
  maxRetries: 2,
  // baseUrl: 'https://www.bulkpicconv.com',
})

async function main() {
  // --- Example 1: convertFile (path in, path out) ---
  try {
    const result = await client.convertFile('./photo.jpg', './photo.webp', {
      format: 'webp',
      quality: 80,
      width: 1920,
    })
    console.log('[convertFile] Saved %d%% (%d → %d bytes)', result.savedPercent, result.inputSize, result.outputSize)
  } catch (err) {
    console.error('[convertFile] Error:', err.message)
  }

  // --- Example 2: convert from Buffer ---
  try {
    const { readFile } = await import('node:fs/promises')
    const imageBuffer = await readFile('./photo.jpg')

    const { buffer, outputSize, inputSize, savedPercent } = await client.convert(imageBuffer, {
      format: 'avif',
      quality: 60,
      grayscale: true,
      filename: 'photo.jpg',
    })

    await writeFile('./photo.avif', buffer)
    console.log('[convert]   Saved %d%% (%d → %d bytes)', savedPercent, inputSize, outputSize)
  } catch (err) {
    console.error('[convert]   Error:', err.message)
  }
}

main()
