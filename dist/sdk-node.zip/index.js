import { readFile, writeFile } from 'node:fs/promises'
import { basename, extname } from 'node:path'

const DEFAULT_BASE_URL = 'https://www.bulkpicconv.com'
const DEFAULT_TIMEOUT = 30_000
const DEFAULT_MAX_RETRIES = 2
const RETRYABLE_STATUSES = new Set([408, 429, 500, 502, 503, 504])

const MIME_TYPES = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  avif: 'image/avif',
  gif: 'image/gif',
  bmp: 'image/bmp',
  tiff: 'image/tiff',
  tif: 'image/tiff',
  heic: 'image/heic',
  heif: 'image/heif',
  zip: 'application/zip',
}

function mimeFromFilename(filename) {
  const ext = extname(filename).slice(1).toLowerCase()
  return MIME_TYPES[ext] || 'application/octet-stream'
}

function headersToObject(headers) {
  const result = {}
  headers.forEach((value, key) => {
    result[key] = value
  })
  return result
}

function retryAfterMs(value) {
  if (!value) return 0
  const seconds = Number(value)
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1000)
  const timestamp = Date.parse(value)
  return Number.isNaN(timestamp) ? 0 : Math.max(0, timestamp - Date.now())
}

export class BulkPicConvError extends Error {
  constructor(message, { status = 0, code = 'network_error', details = undefined, retryAfter = undefined } = {}) {
    super(message)
    this.name = 'BulkPicConvError'
    this.status = status
    this.code = code
    this.details = details
    this.retryAfter = retryAfter
  }
}

export class BulkPicConv {
  constructor({
    apiKey,
    baseUrl = DEFAULT_BASE_URL,
    timeout = DEFAULT_TIMEOUT,
    maxRetries = DEFAULT_MAX_RETRIES,
    retryDelay = 250,
  } = {}) {
    if (!apiKey) throw new Error('BulkPicConv: apiKey is required')
    this.apiKey = apiKey
    this.baseUrl = String(baseUrl).replace(/\/+$/, '')
    this.timeout = Math.max(0, Number(timeout))
    this.maxRetries = Math.max(0, Math.min(5, Number(maxRetries)))
    this.retryDelay = Math.max(0, Number(retryDelay))
  }

  async convert(image, options = {}) {
    return this._imageRequest('/api/v1/convert', image, options)
  }

  async resize(image, options = {}) {
    return this._imageRequest('/api/v1/resize', image, options)
  }

  async crop(image, options = {}) {
    return this._imageRequest('/api/v1/crop', image, options)
  }

  async optimize(image, options = {}) {
    return this._imageRequest('/api/v1/optimize', image, options)
  }

  async watermark(image, watermark, options = {}) {
    const source = await this._readImage(image, options.filename || 'image.jpg')
    const mark = await this._readImage(watermark, options.watermarkFilename || 'watermark.png')
    const fields = { ...options }
    delete fields.filename
    delete fields.watermarkFilename
    return this._multipartRequest(
      '/api/v1/watermark',
      [
        { name: 'image', buffer: source.buffer, filename: source.filename, type: mimeFromFilename(source.filename) },
        { name: 'watermark', buffer: mark.buffer, filename: mark.filename, type: mimeFromFilename(mark.filename) },
      ],
      fields,
    )
  }

  async createBatch(zip, options = {}) {
    const file = await this._readImage(zip, options.filename || 'images.zip')
    const fields = { ...options }
    delete fields.filename
    const result = await this._jsonMultipartRequest(
      '/api/v2/batch',
      [{ name: 'file', buffer: file.buffer, filename: file.filename, type: 'application/zip' }],
      fields,
    )
    return result.data
  }

  async getBatchStatus(jobId) {
    const result = await this._request(`/api/v2/batch/${encodeURIComponent(jobId)}/status`)
    return result.data
  }

  async downloadBatchResult(jobId) {
    return this._request(`/api/v2/batch/${encodeURIComponent(jobId)}/result`, { method: 'GET', binary: true })
  }

  async getUsage() {
    const result = await this._request('/api/v2/usage')
    return result.data
  }

  async getCredits() {
    const result = await this._request('/api/v2/credits')
    return result.data
  }

  // ── AI Methods ──────────────────────────────────────────────

  async aiAltText(images, options = {}) {
    return this._aiRequest('/v1/ai/alt-text', images, options)
  }

  async aiRename(images, options = {}) {
    return this._aiRequest('/v1/ai/rename', images, options)
  }

  async aiSmartCrop(image, options = {}) {
    return this._aiRequest('/v1/ai/smart-crop', [image], options)
  }

  async aiEnhance(image, options = {}) {
    return this._aiRequest('/v1/ai/enhance', [image], options)
  }

  async aiRecommend(images, options = {}) {
    return this._aiRequest('/v1/ai/recommend', images, options)
  }

  async backgroundRemove(image, options = {}) {
    const source = await this._readImage(image, options.filename || 'image.png')
    const fields = { ...options }
    delete fields.filename
    return this._multipartRequest(
      '/api/background-remove',
      [{ name: 'image', buffer: source.buffer, filename: source.filename, type: mimeFromFilename(source.filename) }],
      fields,
    )
  }

  async _aiRequest(path, images, options) {
    const { userProvider, ...rest } = options
    const body = { images, ...rest }
    if (userProvider) body.userProvider = userProvider
    const result = await this._jsonPostRequest(path, body)
    return result.data
  }

  async convertFile(inputPath, outputPath, options = {}) {
    const result = await this.convert(inputPath, options)
    await writeFile(outputPath, result.buffer)
    return {
      outputSize: result.outputSize,
      inputSize: result.inputSize,
      savedPercent: result.savedPercent,
    }
  }

  async _imageRequest(path, image, options) {
    const source = await this._readImage(image, options.filename || 'image.jpg')
    const fields = { ...options }
    delete fields.filename
    return this._multipartRequest(
      path,
      [{ name: 'image', buffer: source.buffer, filename: source.filename, type: mimeFromFilename(source.filename) }],
      fields,
    )
  }

  async _readImage(image, fallbackFilename) {
    if (typeof image === 'string') {
      return { buffer: await readFile(image), filename: basename(image) }
    }
    if (Buffer.isBuffer(image) || image instanceof Uint8Array) {
      return { buffer: Buffer.from(image), filename: fallbackFilename }
    }
    throw new TypeError('BulkPicConv: image must be a Buffer, Uint8Array, or a file path string')
  }

  _createForm(files, fields) {
    const form = new FormData()
    for (const file of files) {
      form.append(file.name, new Blob([file.buffer], { type: file.type }), file.filename)
    }
    for (const [key, value] of Object.entries(fields)) {
      if (value !== undefined && value !== null) {
        form.append(key, typeof value === 'boolean' ? String(value) : String(value))
      }
    }
    return form
  }

  async _multipartRequest(path, files, fields) {
    return this._request(path, {
      method: 'POST',
      bodyFactory: () => this._createForm(files, fields),
      binary: true,
    })
  }

  async _jsonMultipartRequest(path, files, fields) {
    return this._request(path, {
      method: 'POST',
      bodyFactory: () => this._createForm(files, fields),
      binary: false,
    })
  }

  async _jsonPostRequest(path, body) {
    return this._request(path, {
      method: 'POST',
      bodyFactory: () => {
        const form = new FormData()
        // Use JSON body for AI endpoints
        return new Blob([JSON.stringify(body)], { type: 'application/json' })
      },
      binary: false,
      jsonBody: body,
    })
  }

  async _request(path, { method = 'GET', bodyFactory, binary = false, jsonBody } = {}) {
    let attempt = 0
    while (true) {
      const controller = new AbortController()
      const timer = this.timeout > 0 ? setTimeout(() => controller.abort(), this.timeout) : null
      try {
        const reqHeaders = { Authorization: `Bearer ${this.apiKey}` }
        let body
        if (jsonBody) {
          reqHeaders['Content-Type'] = 'application/json'
          body = JSON.stringify(jsonBody)
        } else if (bodyFactory) {
          body = bodyFactory()
        }
        const response = await fetch(`${this.baseUrl}${path}`, {
          method,
          headers: reqHeaders,
          body,
          signal: controller.signal,
        })
        if (!response.ok) {
          const error = await this._buildError(response)
          if (attempt < this.maxRetries && RETRYABLE_STATUSES.has(response.status)) {
            await this._wait(attempt, response.headers.get('retry-after'))
            attempt++
            continue
          }
          throw error
        }
        const headers = headersToObject(response.headers)
        if (binary) {
          const buffer = Buffer.from(await response.arrayBuffer())
          return {
            buffer,
            outputSize: Number(headers['x-output-size'] || buffer.length),
            inputSize: Number(headers['x-input-size'] || 0),
            savedPercent: Number(headers['x-saved-percent'] || 0),
            headers,
          }
        }
        return { data: await response.json(), headers }
      } catch (error) {
        if (error instanceof BulkPicConvError && error.status) throw error
        if (controller.signal.aborted) {
          throw new BulkPicConvError(`BulkPicConv: request timeout after ${this.timeout}ms`, { code: 'timeout' })
        }
        if (attempt < this.maxRetries) {
          await this._wait(attempt)
          attempt++
          continue
        }
        if (error instanceof BulkPicConvError) throw error
        throw new BulkPicConvError(`BulkPicConv: network error - ${error.message}`, { details: error })
      } finally {
        if (timer) clearTimeout(timer)
      }
    }
  }

  async _wait(attempt, retryAfter) {
    const delay = retryAfterMs(retryAfter) || this.retryDelay * 2 ** attempt
    if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay))
  }

  async _buildError(response) {
    let details
    let code = `http_${response.status}`
    try {
      details = await response.json()
      code = details.error || details.code || code
    } catch {
      details = undefined
    }
    const retryAfter = response.headers.get('retry-after') || undefined
    return new BulkPicConvError(`BulkPicConv API error (${response.status}): ${code}`, {
      status: response.status,
      code,
      details,
      retryAfter,
    })
  }
}

export default BulkPicConv
