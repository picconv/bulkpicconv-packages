# @bulkpicconv/node

Official Node.js SDK for the [BulkPicConv](https://www.bulkpicconv.com) image conversion API.

## Features

- Convert images to WebP, AVIF, JPEG, or PNG
- Resize, rotate, grayscale, and blur
- Zero dependencies (uses native `fetch`, `FormData`, `Blob`)
- Works with Node.js 18+

## Installation

Copy the `sdk/node/` directory into your project, or install from a local path:

```bash
npm install @bulkpicconv/node --prefix ./local-packages
```

Since this SDK has no dependencies, you can also just copy `index.js` directly.

## Quick Start

```js
import { BulkPicConv } from '@bulkpicconv/node'

const client = new BulkPicConv({
  apiKey: 'sk_your_api_key',
  // baseUrl: 'https://www.bulkpicconv.com',  // optional, this is the default
})

// Convert a file path and save the result
const result = await client.convertFile('./photo.jpg', './photo.webp', {
  format: 'webp',
  quality: 80,
  width: 1920,
})

console.log(`Saved ${result.savedPercent}% (${result.inputSize} → ${result.outputSize} bytes)`)
```

## API

### `new BulkPicConv({ apiKey, baseUrl, timeout, maxRetries, retryDelay })`

| Parameter    | Type     | Required | Default                       |
| ------------ | -------- | -------- | ----------------------------- |
| `apiKey`     | `string` | Yes      | -                             |
| `baseUrl`    | `string` | No       | `https://www.bulkpicconv.com` |
| `timeout`    | `number` | No       | `30000` ms                    |
| `maxRetries` | `number` | No       | `2`                           |
| `retryDelay` | `number` | No       | `250` ms                      |

### `client.convert(image, options)`

Convert an image and return the result as a Buffer.

**Parameters:**

- `image` — `Buffer | string`: Image buffer or file path
- `options`:
  - `format` (`string`): `webp` | `avif` | `jpeg` | `png` (default: `webp`)
  - `quality` (`number`): 1-100 (default: 75)
  - `width` (`number`): Output width
  - `height` (`number`): Output height
  - `fit` (`string`): `cover` | `contain` | `fill` | `inside` | `outside`
  - `grayscale` (`boolean`): Convert to grayscale
  - `blur` (`number`): Blur radius 0.3-100
  - `rotate` (`number`): Rotation angle 0-360
  - `filename` (`string`): Filename hint when passing a Buffer

**Returns:** `{ buffer, outputSize, inputSize, savedPercent }`

### `client.convertFile(inputPath, outputPath, options)`

Read a file, convert it, and write the result to `outputPath`.

**Returns:** `{ outputSize, inputSize, savedPercent }`

### Other image methods

The SDK also provides `resize`, `crop`, `optimize`, and `watermark`, each returning `{ buffer, outputSize, inputSize, savedPercent, headers }`. Batch workflows use `createBatch`, `getBatchStatus`, and `downloadBatchResult`.

Requests retry network errors and HTTP 408, 429, 500, 502, 503, and 504. Other HTTP 4xx errors throw `BulkPicConvError` with `status`, `code`, `details`, and `retryAfter`.

### AI Methods

```js
// Generate alt text for images
const result = await client.aiAltText(['path/to/image.jpg'], {
  language: 'en',
})
// → { altText, keywords, contentType, confidence }

// AI-suggest renamed filenames
const rename = await client.aiRename(['photo.jpg'])

// AI smart crop for specific platforms
const crop = await client.aiSmartCrop('banner.jpg', {
  platforms: ['facebook', 'instagram'],
})

// AI enhance image quality
const enhanced = await client.aiEnhance('old-photo.jpg')

// AI recommend optimal format
const rec = await client.aiRecommend(['photo.jpg'])
```

### BYOK (Bring Your Own Key)

Use your own OpenAI-compatible API key for AI methods:

```js
const result = await client.aiAltText(['image.jpg'], {
  userProvider: {
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-4o',
    apiKey: 'sk-your-openai-key',
  },
})
```

### Background Removal

```js
const { buffer, outputSize } = await client.backgroundRemove('product.jpg')
// buffer contains the transparent PNG
```

## Examples

### Convert from a Buffer

```js
import { readFile } from 'node:fs/promises'
import { BulkPicConv } from '@bulkpicconv/node'

const client = new BulkPicConv({ apiKey: 'sk_your_api_key' })
const imageBuffer = await readFile('./photo.jpg')

const { buffer, savedPercent } = await client.convert(imageBuffer, {
  format: 'avif',
  quality: 60,
  filename: 'photo.jpg',
})

console.log(`Saved ${savedPercent}%`)
```

### Batch Conversion

```js
import { BulkPicConv } from '@bulkpicconv/node'

const client = new BulkPicConv({ apiKey: 'sk_your_api_key' })

for (const file of ['a.jpg', 'b.jpg', 'c.jpg']) {
  const { savedPercent } = await client.convertFile(file, file.replace('.jpg', '.webp'), {
    format: 'webp',
    quality: 80,
  })
  console.log(`${file}: saved ${savedPercent}%`)
}
```

## Error Handling

The SDK throws `Error` with descriptive messages on failure:

```js
try {
  await client.convertFile('input.jpg', 'output.webp', { format: 'webp' })
} catch (err) {
  console.error('Conversion failed:', err.message)
  // e.g. "BulkPicConv API error (401): missing_or_invalid_api_key"
}
```

## License

MIT
