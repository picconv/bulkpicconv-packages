export class BulkPicConvError extends Error {
  constructor(message, options = {})
  status: number
  code: string
  details: unknown
  retryAfter?: string
}

export interface ImageOptions {
  filename?: string
  format?: 'webp' | 'avif' | 'jpeg' | 'png'
  quality?: number
  width?: number
  height?: number
  fit?: 'cover' | 'contain' | 'fill' | 'inside' | 'outside'
  grayscale?: boolean
  blur?: number
  rotate?: number
  [key: string]: unknown
}

export interface BinaryResult {
  buffer: Buffer
  outputSize: number
  inputSize: number
  savedPercent: number
  headers: Record<string, string>
}

export interface UserProvider {
  baseUrl: string
  model: string
  apiKey?: string
  useAccountKey?: boolean
}

export interface AiOptions {
  userProvider?: UserProvider
  [key: string]: unknown
}

export interface AltTextOptions extends AiOptions {
  language?: 'en' | 'zh' | 'es' | 'fr' | 'de' | 'ja' | 'ko' | 'pt' | 'it'
  style?: 'descriptive' | 'concise' | 'seo'
}

export interface EnhanceOptions extends AiOptions {
  mode?: 'upscale' | 'denoise' | 'deblur' | 'auto'
  intensity?: 1 | 2 | 3
  returnPreview?: boolean
}

export interface SmartCropOptions extends AiOptions {
  platforms?: string[]
  customRatio?: { width: number; height: number }
  returnCroppedImage?: boolean
}

export interface RecommendOptions extends AiOptions {
  useCase?: 'web' | 'ecommerce' | 'social-media' | 'print' | 'archive' | 'general'
}

export interface BackgroundRemoveOptions {
  format?: 'png' | 'webp'
  filename?: string
}

export class BulkPicConv {
  constructor(options: { apiKey: string; baseUrl?: string; timeout?: number; maxRetries?: number; retryDelay?: number })
  convert(image: Buffer | Uint8Array | string, options?: ImageOptions): Promise<BinaryResult>
  resize(image: Buffer | Uint8Array | string, options?: ImageOptions): Promise<BinaryResult>
  crop(image: Buffer | Uint8Array | string, options?: ImageOptions): Promise<BinaryResult>
  optimize(image: Buffer | Uint8Array | string, options?: ImageOptions): Promise<BinaryResult>
  watermark(
    image: Buffer | Uint8Array | string,
    watermark: Buffer | Uint8Array | string,
    options?: ImageOptions,
  ): Promise<BinaryResult>
  createBatch(zip: Buffer | Uint8Array | string, options?: ImageOptions): Promise<Record<string, unknown>>
  getBatchStatus(jobId: string): Promise<Record<string, unknown>>
  downloadBatchResult(jobId: string): Promise<BinaryResult>
  getUsage(): Promise<Record<string, unknown>>
  getCredits(): Promise<Record<string, unknown>>
  aiAltText(images: string[], options?: AltTextOptions): Promise<Record<string, unknown>>
  aiRename(images: object[], options?: AiOptions): Promise<Record<string, unknown>>
  aiSmartCrop(image: string, options?: SmartCropOptions): Promise<Record<string, unknown>>
  aiEnhance(image: string, options?: EnhanceOptions): Promise<Record<string, unknown>>
  aiRecommend(images: object[], options?: RecommendOptions): Promise<Record<string, unknown>>
  backgroundRemove(image: Buffer | Uint8Array | string, options?: BackgroundRemoveOptions): Promise<BinaryResult>
  convertFile(
    inputPath: string,
    outputPath: string,
    options?: ImageOptions,
  ): Promise<Omit<BinaryResult, 'buffer' | 'headers'>>
}

export default BulkPicConv
