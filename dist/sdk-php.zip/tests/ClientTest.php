<?php

declare(strict_types=1);

namespace BulkPicConv\Tests;

use BulkPicConv\Client;
use PHPUnit\Framework\TestCase;

final class ClientTest extends TestCase
{
    public function testClientCanBeConstructed(): void
    {
        $client = new Client('sk_test', 'http://localhost:3000', 1, 0);
        self::assertInstanceOf(Client::class, $client);
    }
}
