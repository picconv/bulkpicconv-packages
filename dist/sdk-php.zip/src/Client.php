<?php

declare(strict_types=1);

namespace BulkPicConv;

use CURLFile;
use RuntimeException;

class Client
{
    private const DEFAULT_BASE_URL = 'https://www.bulkpicconv.com';
    private const RETRYABLE_STATUSES = [408, 429, 500, 502, 503, 504];

    public function __construct(
        private readonly string $apiKey,
        private readonly string $baseUrl = self::DEFAULT_BASE_URL,
        private readonly int $timeout = 30,
        private readonly int $maxRetries = 2,
        private readonly int $retryDelayMilliseconds = 250,
    ) {
        if ($this->apiKey === '') {
            throw new RuntimeException('BulkPicConv: apiKey is required');
        }
    }

    public function convert(string|array $image, array $options = []): array
    {
        return $this->imageRequest('/api/v1/convert', $image, $options);
    }

    public function resize(string|array $image, array $options = []): array
    {
        return $this->imageRequest('/api/v1/resize', $image, $options);
    }

    public function crop(string|array $image, array $options = []): array
    {
        return $this->imageRequest('/api/v1/crop', $image, $options);
    }

    public function optimize(string|array $image, array $options = []): array
    {
        return $this->imageRequest('/api/v1/optimize', $image, $options);
    }

    public function watermark(string|array $image, string|array $watermark, array $options = []): array
    {
        $filename = $options['filename'] ?? 'image.jpg';
        $watermarkFilename = $options['watermarkFilename'] ?? 'watermark.png';
        unset($options['filename'], $options['watermarkFilename']);
        $files = [
            'image' => $this->filePart($image, $filename),
            'watermark' => $this->filePart($watermark, $watermarkFilename),
        ];
        return $this->multipartRequest('/api/v1/watermark', $files, $options, true);
    }

    public function createBatch(string|array $archive, array $options = []): array
    {
        $filename = $options['filename'] ?? 'images.zip';
        unset($options['filename']);
        return $this->multipartRequest('/api/v2/batch', [
            'file' => $this->filePart($archive, $filename, 'application/zip'),
        ], $options, false)['data'];
    }

    public function getBatchStatus(string $jobId): array
    {
        $result = $this->request('/api/v2/batch/' . rawurlencode($jobId) . '/status');
        return $result['data'];
    }

    public function downloadBatchResult(string $jobId): array
    {
        return $this->request('/api/v2/batch/' . rawurlencode($jobId) . '/result', 'GET', [], true);
    }

    public function getUsage(): array
    {
        return $this->request('/api/v2/usage')['data'];
    }

    public function getCredits(): array
    {
        return $this->request('/api/v2/credits')['data'];
    }

    // ── AI Methods ──────────────────────────────────────────────

    public function aiAltText(array $images, array $options = []): array
    {
        return $this->aiRequest('/v1/ai/alt-text', $images, $options);
    }

    public function aiRename(array $images, array $options = []): array
    {
        return $this->aiRequest('/v1/ai/rename', $images, $options);
    }

    public function aiSmartCrop(string $image, array $options = []): array
    {
        return $this->aiRequest('/v1/ai/smart-crop', [$image], $options);
    }

    public function aiEnhance(string $image, array $options = []): array
    {
        return $this->aiRequest('/v1/ai/enhance', [$image], $options);
    }

    public function aiRecommend(array $images, array $options = []): array
    {
        return $this->aiRequest('/v1/ai/recommend', $images, $options);
    }

    public function backgroundRemove(string|array $image, array $options = []): array
    {
        $filename = $options['filename'] ?? 'image.png';
        unset($options['filename']);
        return $this->multipartRequest('/api/background-remove', [
            'image' => $this->filePart($image, $filename),
        ], $options, true);
    }

    private function aiRequest(string $path, array $images, array $options): array
    {
        $body = array_merge(['images' => $images], $options);
        return $this->jsonPostRequest($path, $body)['data'];
    }

    private function jsonPostRequest(string $path, array $body): array
    {
        return $this->request($path, 'POST', $body, false, true);
    }

    public function convertFile(string $inputPath, string $outputPath, array $options = []): array
    {
        $result = $this->convert($inputPath, $options);
        file_put_contents($outputPath, $result['buffer']);
        return [
            'outputSize' => $result['outputSize'],
            'inputSize' => $result['inputSize'],
            'savedPercent' => $result['savedPercent'],
        ];
    }

    private function imageRequest(string $path, string|array $image, array $options): array
    {
        $filename = $options['filename'] ?? 'image.jpg';
        unset($options['filename']);
        return $this->multipartRequest($path, [
            'image' => $this->filePart($image, $filename),
        ], $options, true);
    }

    private function filePart(string|array $image, string $fallbackFilename, ?string $contentType = null): CURLFile|string
    {
        if (is_string($image) && is_file($image)) {
            return new CURLFile($image, $contentType ?: mime_content_type($image) ?: 'application/octet-stream', basename($image));
        }
        if (is_array($image) && isset($image['data'])) {
            $path = tempnam(sys_get_temp_dir(), 'bpc_');
            if ($path === false || file_put_contents($path, (string) $image['data']) === false) {
                throw new RuntimeException('BulkPicConv: unable to create temporary upload file');
            }
            return new CURLFile($path, $contentType ?: ($image['contentType'] ?? 'application/octet-stream'), $image['filename'] ?? $fallbackFilename);
        }
        if (is_string($image)) {
            $path = tempnam(sys_get_temp_dir(), 'bpc_');
            if ($path === false || file_put_contents($path, $image) === false) {
                throw new RuntimeException('BulkPicConv: unable to create temporary upload file');
            }
            return new CURLFile($path, $contentType ?: 'application/octet-stream', $fallbackFilename);
        }
        throw new RuntimeException('BulkPicConv: image must be a file path or byte array');
    }

    private function multipartRequest(string $path, array $files, array $fields, bool $binary): array
    {
        return $this->request($path, 'POST', array_merge($fields, $files), $binary);
    }

    private function request(string $path, string $method = 'GET', array $body = [], bool $binary = false, bool $json = false): array
    {
        $attempt = 0;
        do {
            $handle = curl_init($this->normalizedBaseUrl() . $path);
            if ($handle === false) {
                throw new RuntimeException('BulkPicConv: unable to initialize cURL');
            }
            $headers = [
                'Authorization: Bearer ' . $this->apiKey,
                'Accept: */*',
            ];
            if ($json && $method === 'POST') {
                $headers[] = 'Content-Type: application/json';
                $body = json_encode($body);
            }
            curl_setopt_array($handle, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_CONNECTTIMEOUT => $this->timeout,
                CURLOPT_TIMEOUT => $this->timeout,
            ]);
            if ($method === 'POST') {
                curl_setopt($handle, CURLOPT_POSTFIELDS, $body);
            }
            $payload = curl_exec($handle);
            $curlError = curl_error($handle);
            $status = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
            $contentType = (string) curl_getinfo($handle, CURLINFO_CONTENT_TYPE);
            curl_close($handle);

            if ($payload === false) {
                if ($attempt < $this->maxRetries) {
                    $this->sleep($attempt);
                    $attempt++;
                    continue;
                }
                throw new BulkPicConvException('BulkPicConv: network error - ' . $curlError, details: $curlError);
            }

            if ($status >= 200 && $status < 300) {
                if ($binary) {
                    return [
                        'buffer' => $payload,
                        'outputSize' => strlen($payload),
                        'inputSize' => 0,
                        'savedPercent' => 0,
                        'headers' => ['content-type' => $contentType],
                    ];
                }
                return ['data' => json_decode($payload, true, 512, JSON_THROW_ON_ERROR), 'headers' => ['content-type' => $contentType]];
            }

            $details = json_decode($payload, true);
            $code = is_array($details) ? ($details['error'] ?? $details['code'] ?? 'http_' . $status) : 'http_' . $status;
            if (in_array($status, self::RETRYABLE_STATUSES, true) && $attempt < $this->maxRetries) {
                $this->sleep($attempt);
                $attempt++;
                continue;
            }
            throw new BulkPicConvException(
                "BulkPicConv API error ({$status}): {$code}",
                status: $status,
                codeValue: $code,
                details: $details,
            );
        } while (true);
    }

    private function normalizedBaseUrl(): string
    {
        return rtrim($this->baseUrl, '/');
    }

    private function sleep(int $attempt): void
    {
        $delay = $this->retryDelayMilliseconds * (2 ** $attempt);
        if ($delay > 0) {
            usleep($delay * 1000);
        }
    }
}
