<?php

declare(strict_types=1);

namespace BulkPicConv;

use RuntimeException;

class BulkPicConvException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly int $status = 0,
        public readonly string $codeValue = 'network_error',
        public readonly mixed $details = null,
        public readonly ?string $retryAfter = null,
    ) {
        parent::__construct($message);
    }

    public function apiCode(): string
    {
        return $this->codeValue;
    }
}
