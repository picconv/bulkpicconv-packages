# BulkPicConv PHP SDK

Official PHP 8.1+ SDK for the BulkPicConv image conversion API.

## Requirements

- PHP 8.1+
- cURL extension
- Composer for autoloading and tests

## Installation

```bash
composer require bulkpicconv/php-sdk
```

## Quick start

```php
use BulkPicConv\Client;

$client = new Client('sk_your_api_key');
$result = $client->convertFile('photo.jpg', 'photo.webp', [
    'format' => 'webp',
    'quality' => 80,
]);
echo $result['savedPercent'];
```

## Methods

- `convert($image, $options)`
- `resize($image, $options)`
- `crop($image, $options)`
- `optimize($image, $options)`
- `watermark($image, $watermark, $options)`
- `createBatch($archive, $options)`
- `getBatchStatus($jobId)`
- `downloadBatchResult($jobId)`
- `convertFile($inputPath, $outputPath, $options)`
- `aiAltText($images, $options)` — Generate descriptive alt text using AI
- `aiRename($images, $options)` — AI-suggest renamed filenames
- `aiSmartCrop($image, $options)` — AI smart crop for platforms
- `aiEnhance($image, $options)` — AI enhance image quality
- `aiRecommend($images, $options)` — AI recommend optimal format
- `backgroundRemove($image, $options)` — Remove image background

Image inputs can be file paths or byte arrays in the form `['data' => $bytes, 'filename' => 'photo.jpg']`.

## AI Methods

```php
// Generate alt text
$result = $client->aiAltText(['photo.jpg'], ['language' => 'en']);
// → ['alt_text' => '...', 'keywords' => [...], 'confidence' => 0.95]

// Remove background
$result = $client->backgroundRemove('product.jpg');
// $result['buffer'] contains the transparent PNG
```

## BYOK (Bring Your Own Key)

Use your own OpenAI-compatible API key for AI methods:

```php
$result = $client->aiAltText(['image.jpg'], [
    'userProvider' => [
        'baseUrl' => 'https://api.openai.com/v1',
        'model' => 'gpt-4o',
        'apiKey' => 'sk-your-openai-key',
    ],
]);
```

## Configuration

```php
$client = new Client(
    'sk_your_api_key',
    'http://localhost:3000',
    timeout: 30,
    maxRetries: 2,
);
```

The client retries network failures and HTTP 408, 429, 500, 502, 503, and 504. Other HTTP 4xx errors throw `BulkPicConvException` immediately.

## Tests

```bash
composer install
composer test --working-dir=sdk/php
php -l sdk/php/src/Client.php
```
