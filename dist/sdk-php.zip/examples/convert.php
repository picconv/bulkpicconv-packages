<?php

declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

use BulkPicConv\Client;
use BulkPicConv\BulkPicConvException;

$client = new Client('sk_your_api_key', timeout: 30, maxRetries: 2);

try {
    $result = $client->convertFile('photo.jpg', 'photo.webp', [
        'format' => 'webp',
        'quality' => 80,
    ]);
    echo "Saved {$result['savedPercent']}%\n";
} catch (BulkPicConvException $error) {
    echo $error->apiCode() . " ({$error->status})\n";
}
