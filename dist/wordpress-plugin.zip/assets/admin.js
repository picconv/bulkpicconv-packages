/**
 * BulkPicConv Admin Scripts
 */
;(function ($) {
  'use strict'

  // Test API Connection
  $(document).on('click', '.bpc-test-connection', function (e) {
    e.preventDefault()

    var $btn = $(this)
    var originalText = $btn.text()

    $btn.prop('disabled', true).text(bpcAdmin.strings.testing)

    // First save settings
    $('form[action="options.php"]').submit()
  })

  // Verify License
  $(document).on('click', '.bpc-verify-license', function (e) {
    e.preventDefault()

    var $btn = $(this)
    var $input = $('input[name="bpc_settings[license_key]"]')
    var licenseKey = $input.val().trim()

    if (!licenseKey) {
      alert('Please enter a license key.')
      return
    }

    $btn.prop('disabled', true).text('Verifying...')

    $.ajax({
      url: bpcAdmin.ajaxUrl,
      method: 'POST',
      data: {
        action: 'bpc_verify_license',
        nonce: bpcAdmin.nonce,
        license_key: licenseKey,
      },
      success: function (response) {
        if (response.success) {
          alert('License verified! Plan: ' + response.data.plan)
          location.reload()
        } else {
          alert('Error: ' + response.data)
        }
      },
      error: function () {
        alert('Connection error. Please try again.')
      },
      complete: function () {
        $btn.prop('disabled', false).text('Verify License')
      },
    })
  })

  // Convert Single Image (Attachment Meta Box)
  $(document).on('click', '.bpc-convert-single', function (e) {
    e.preventDefault()

    var $btn = $(this)
    var $status = $('.bpc-convert-status')
    var attachmentId = $btn.data('attachment-id')

    $btn.prop('disabled', true).text('Converting...')
    $status.hide()

    $.ajax({
      url: bpcAdmin.ajaxUrl,
      method: 'POST',
      data: {
        action: 'bpc_convert_image',
        nonce: bpcAdmin.nonce,
        attachment_id: attachmentId,
      },
      success: function (response) {
        if (response.success) {
          $status.text(response.data.message).removeClass('error').addClass('success').show()

          // Reload after 2 seconds to show updated file
          setTimeout(function () {
            location.reload()
          }, 2000)
        } else {
          $status
            .text('Error: ' + response.data)
            .removeClass('success')
            .addClass('error')
            .show()
          $btn.prop('disabled', false).text('Convert Now')
        }
      },
      error: function () {
        $status.text('Connection error. Please try again.').removeClass('success').addClass('error').show()
        $btn.prop('disabled', false).text('Convert Now')
      },
    })
  })
})(jQuery)
