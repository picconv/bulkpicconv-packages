<?php
/**
 * Plugin Name: BulkPicConv - WebP & AVIF Converter
 * Plugin URI: https://www.bulkpicconv.com
 * Description: Automatically convert uploaded images to WebP/AVIF format using BulkPicConv API. Share your Pro subscription with WordPress.
 * Version: 1.0.0
 * Author: BulkPicConv
 * Author URI: https://www.bulkpicconv.com
 * License: GPL v2 or later
 * Text Domain: bulkpicconv
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BPC_VERSION', '1.0.0');
define('BPC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BPC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once BPC_PLUGIN_DIR . 'includes/class-bpc-api.php';
require_once BPC_PLUGIN_DIR . 'includes/class-bpc-settings.php';
require_once BPC_PLUGIN_DIR . 'includes/class-bpc-converter.php';

/**
 * Main plugin class
 */
class BulkPicConv {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Initialize components
        BPC_Settings::init();
        BPC_Converter::init();
        
        // Admin hooks
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_notices', array($this, 'show_admin_notices'));
        
        // Plugin action links
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'bulkpicconv') === false) {
            return;
        }
        
        wp_enqueue_style(
            'bpc-admin',
            BPC_PLUGIN_URL . 'assets/admin.css',
            array(),
            BPC_VERSION
        );
        
        wp_enqueue_script(
            'bpc-admin',
            BPC_PLUGIN_URL . 'assets/admin.js',
            array('jquery'),
            BPC_VERSION,
            true
        );
        
        wp_localize_script('bpc-admin', 'bpcAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bpc_admin_nonce'),
            'strings' => array(
                'testing' => __('Testing connection...', 'bulkpicconv'),
                'success' => __('Connection successful!', 'bulkpicconv'),
                'error' => __('Connection failed. Please check your settings.', 'bulkpicconv'),
            ),
        ));
    }
    
    /**
     * Show admin notices
     */
    public function show_admin_notices() {
        $settings = get_option('bpc_settings', array());
        
        // Show notice if API key is not configured
        if (empty($settings['api_key'])) {
            $settings_url = admin_url('options-general.php?page=bulkpicconv');
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p>' . sprintf(
                __('BulkPicConv: %s to start converting images automatically.', 'bulkpicconv'),
                '<a href="' . esc_url($settings_url) . '">' . __('Configure API settings', 'bulkpicconv') . '</a>'
            ) . '</p>';
            echo '</div>';
        }
        
        // Show success notice after license verification
        if (isset($_GET['bpc_verified']) && $_GET['bpc_verified'] === '1') {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . __('License verified successfully! Pro features are now active.', 'bulkpicconv') . '</p>';
            echo '</div>';
        }
    }
    
    /**
     * Add plugin action links
     */
    public function plugin_action_links($links) {
        $settings_link = '<a href="' . admin_url('options-general.php?page=bulkpicconv') . '">' . __('Settings', 'bulkpicconv') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize plugin
add_action('plugins_loaded', function() {
    BulkPicConv::get_instance();
});

// Activation hook
register_activation_hook(__FILE__, function() {
    // Set default options
    $defaults = array(
        'api_key' => '',
        'api_url' => 'https://www.bulkpicconv.com/api/v1',
        'format' => 'webp',
        'quality' => 80,
        'auto_convert' => true,
        'auto_alt_text' => false,
        'picture_tag_output' => false,
        'convert_existing' => false,
        'license_key' => '',
    );
    
    if (!get_option('bpc_settings')) {
        add_option('bpc_settings', $defaults);
    }
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Clean up scheduled events if any
    wp_clear_scheduled_hook('bpc_cleanup_temp_files');
});
