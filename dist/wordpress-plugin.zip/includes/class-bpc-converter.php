<?php
/**
 * Image Converter - Hooks into WordPress media upload
 */

if (!defined('ABSPATH')) {
    exit;
}

class BPC_Converter {
    
    public static function init() {
        // Hook into media upload
        add_filter('wp_handle_upload', array(__CLASS__, 'handle_upload'), 10, 2);
        
        // Add bulk action for converting existing images
        add_filter('bulk_actions-upload', array(__CLASS__, 'add_bulk_actions'));
        add_filter('handle_bulk_actions-upload', array(__CLASS__, 'handle_bulk_action'), 10, 3);
        
        // Admin notices for bulk actions
        add_action('admin_notices', array(__CLASS__, 'bulk_action_notices'));
        
        // Add meta box to attachment edit page
        add_action('add_meta_boxes_attachment', array(__CLASS__, 'add_attachment_meta_box'));
        
        // AJAX: Convert single image
        add_action('wp_ajax_bpc_convert_image', array(__CLASS__, 'ajax_convert_image'));
        
        // AI Alt Text: auto-generate on upload
        add_filter('wp_generate_attachment_metadata', array(__CLASS__, 'auto_generate_alt_text'), 20, 2);
        
        // Picture tag: output <picture> with WebP source
        if (!is_admin()) {
            add_filter('post_thumbnail_html', array(__CLASS__, 'picture_tag_filter'), 10, 5);
            add_filter('the_content', array(__CLASS__, 'content_picture_tag_filter'));
        }
    }
    
    /**
     * Handle uploaded image - auto convert if enabled
     */
    public static function handle_upload($upload, $overrides = array()) {
        $settings = get_option('bpc_settings', array());
        
        // Check if auto convert is enabled
        if (empty($settings['auto_convert'])) {
            return $upload;
        }
        
        // Check if API key is configured
        if (empty($settings['api_key'])) {
            return $upload;
        }
        
        // Only convert images
        if (empty($upload['type']) || strpos($upload['type'], 'image/') !== 0) {
            return $upload;
        }
        
        // Skip SVG and GIF (not supported by API)
        if (in_array($upload['type'], array('image/svg+xml', 'image/gif'))) {
            return $upload;
        }
        
        // Convert the image
        $converted = self::convert_and_replace($upload['file'], $settings);
        
        if (!is_wp_error($converted)) {
            // Update upload info
            $upload['file'] = $converted['new_path'];
            $upload['url'] = $converted['new_url'];
            $upload['type'] = $converted['new_type'];
        }
        
        return $upload;
    }
    
    /**
     * Convert image and replace original
     */
    public static function convert_and_replace($file_path, $settings = null) {
        if ($settings === null) {
            $settings = get_option('bpc_settings', array());
        }
        
        $api = new BPC_API();
        
        $options = array(
            'format' => $settings['format'] ?? 'webp',
            'quality' => $settings['quality'] ?? 80,
        );
        
        $result = $api->convert_image($file_path, $options);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Generate new file path
        $path_info = pathinfo($file_path);
        $ext_map = array(
            'webp' => 'webp',
            'avif' => 'avif',
            'jpeg' => 'jpg',
            'png' => 'png',
        );
        $new_ext = $ext_map[$options['format']] ?? $options['format'];
        $new_path = $path_info['dirname'] . '/' . $path_info['filename'] . '.' . $new_ext;
        
        // Save converted image
        $saved = file_put_contents($new_path, $result['data']);
        
        if ($saved === false) {
            return new WP_Error('save_failed', __('Failed to save converted image.', 'bulkpicconv'));
        }
        
        // Remove original file if different
        if ($new_path !== $file_path && file_exists($file_path)) {
            @unlink($file_path);
        }
        
        // Get new URL
        $upload_dir = wp_upload_dir();
        $new_url = str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $new_path);
        
        // Get new MIME type
        $mime_types = array(
            'webp' => 'image/webp',
            'avif' => 'image/avif',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
        );
        $new_type = $mime_types[$options['format']] ?? 'image/' . $options['format'];
        
        // Log conversion
        self::log_conversion(array(
            'original_path' => $file_path,
            'new_path' => $new_path,
            'format' => $options['format'],
            'input_size' => $result['input_size'],
            'output_size' => $result['output_size'],
            'saved_percent' => $result['saved_percent'],
        ));
        
        return array(
            'new_path' => $new_path,
            'new_url' => $new_url,
            'new_type' => $new_type,
            'saved_percent' => $result['saved_percent'],
        );
    }
    
    /**
     * Add bulk actions
     */
    public static function add_bulk_actions($actions) {
        $settings = get_option('bpc_settings', array());
        
        if (!empty($settings['api_key'])) {
            $actions['bpc_convert'] = __('Convert to WebP/AVIF', 'bulkpicconv');
        }
        
        return $actions;
    }
    
    /**
     * Handle bulk action
     */
    public static function handle_bulk_action($redirect_to, $action, $post_ids) {
        if ($action !== 'bpc_convert') {
            return $redirect_to;
        }
        
        $settings = get_option('bpc_settings', array());
        $converted = 0;
        $failed = 0;
        
        foreach ($post_ids as $post_id) {
            $file_path = get_attached_file($post_id);
            
            if (!$file_path || !file_exists($file_path)) {
                $failed++;
                continue;
            }
            
            // Check if it's an image
            $mime = get_post_mime_type($post_id);
            if (strpos($mime, 'image/') !== 0 || in_array($mime, array('image/svg+xml', 'image/gif'))) {
                continue;
            }
            
            $result = self::convert_and_replace($file_path, $settings);
            
            if (is_wp_error($result)) {
                $failed++;
            } else {
                // Update attachment metadata
                $new_path = $result['new_path'];
                wp_update_attachment_metadata($post_id, array(
                    'file' => $new_path,
                    'width' => 0,
                    'height' => 0,
                ));
                
                // Update post meta
                update_post_meta($post_id, '_wp_attached_file', $new_path);
                
                $converted++;
            }
        }
        
        $redirect_to = add_query_arg(array(
            'bpc_converted' => $converted,
            'bpc_failed' => $failed,
        ), $redirect_to);
        
        return $redirect_to;
    }
    
    /**
     * Show bulk action notices
     */
    public static function bulk_action_notices() {
        if (isset($_GET['bpc_converted'])) {
            $converted = absint($_GET['bpc_converted']);
            $failed = absint($_GET['bpc_failed'] ?? 0);
            
            if ($converted > 0) {
                printf(
                    '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                    sprintf(
                        _n('%d image converted successfully.', '%d images converted successfully.', $converted, 'bulkpicconv'),
                        $converted
                    )
                );
            }
            
            if ($failed > 0) {
                printf(
                    '<div class="notice notice-error is-dismissible"><p>%s</p></div>',
                    sprintf(
                        _n('%d image failed to convert.', '%d images failed to convert.', $failed, 'bulkpicconv'),
                        $failed
                    )
                );
            }
        }
    }
    
    /**
     * Add meta box to attachment edit page
     */
    public static function add_attachment_meta_box($post) {
        if (wp_attachment_is_image($post)) {
            add_meta_box(
                'bpc_convert_box',
                __('BulkPicConv', 'bulkpicconv'),
                array(__CLASS__, 'render_attachment_meta_box'),
                'attachment',
                'side'
            );
        }
    }
    
    /**
     * Render attachment meta box
     */
    public static function render_attachment_meta_box($post) {
        $settings = get_option('bpc_settings', array());
        
        if (empty($settings['api_key'])) {
            echo '<p>' . __('API key not configured. Please configure in Settings.', 'bulkpicconv') . '</p>';
            return;
        }
        
        $file_path = get_attached_file($post->ID);
        $file_size = file_exists($file_path) ? size_format(filesize($file_path)) : __('Unknown', 'bulkpicconv');
        
        ?>
        <p>
            <strong><?php _e('Current file:', 'bulkpicconv'); ?></strong><br>
            <?php echo esc_html(basename($file_path)); ?><br>
            <?php echo esc_html($file_size); ?>
        </p>
        <p>
            <button type="button" class="button bpc-convert-single" data-attachment-id="<?php echo esc_attr($post->ID); ?>">
                <?php _e('Convert Now', 'bulkpicconv'); ?>
            </button>
        </p>
        <p class="bpc-convert-status" style="display:none;"></p>
        <?php
    }
    
    /**
     * AJAX: Convert single image
     */
    public static function ajax_convert_image() {
        check_ajax_referer('bpc_admin_nonce', 'nonce');
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error(__('Permission denied.', 'bulkpicconv'));
        }
        
        $attachment_id = absint($_POST['attachment_id'] ?? 0);
        
        if (!$attachment_id) {
            wp_send_json_error(__('Invalid attachment ID.', 'bulkpicconv'));
        }
        
        $file_path = get_attached_file($attachment_id);
        
        if (!$file_path || !file_exists($file_path)) {
            wp_send_json_error(__('File not found.', 'bulkpicconv'));
        }
        
        $settings = get_option('bpc_settings', array());
        $result = self::convert_and_replace($file_path, $settings);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Converted successfully! Saved %d%%.', 'bulkpicconv'),
                $result['saved_percent']
            ),
            'new_url' => $result['new_url'],
            'saved_percent' => $result['saved_percent'],
        ));
    }
    
    /**
     * Log conversion
     */
    private static function log_conversion($data) {
        $log = get_option('bpc_conversion_log', array());
        
        $log[] = array(
            'time' => current_time('mysql'),
            'original' => basename($data['original_path']),
            'format' => $data['format'],
            'input_size' => $data['input_size'],
            'output_size' => $data['output_size'],
            'saved_percent' => $data['saved_percent'],
        );
        
        // Keep only last 100 entries
        if (count($log) > 100) {
            $log = array_slice($log, -100);
        }
        
        update_option('bpc_conversion_log', $log, false);
    }
    
    /**
     * Auto-generate AI alt text for uploaded images
     */
    public static function auto_generate_alt_text($metadata, $attachment_id) {
        $settings = get_option('bpc_settings', array());
        
        if (empty($settings['auto_alt_text'])) {
            return $metadata;
        }
        
        if (empty($settings['api_key'])) {
            return $metadata;
        }
        
        // Only process images
        if (empty($metadata['width']) || empty($metadata['height'])) {
            return $metadata;
        }
        
        // Skip if alt text already set
        $existing_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        if (!empty($existing_alt)) {
            return $metadata;
        }
        
        $file_path = get_attached_file($attachment_id);
        if (!$file_path || !file_exists($file_path)) {
            return $metadata;
        }
        
        $api = new BPC_API();
        $language = substr(get_locale(), 0, 2);
        $result = $api->generate_alt_text($file_path, $language);
        
        if (!is_wp_error($result) && !empty($result['alt_text'])) {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($result['alt_text']));
            
            // Log for admin notice
            self::log_conversion(array(
                'original_path' => $file_path,
                'format' => 'ai-alt-text',
                'input_size' => filesize($file_path),
                'output_size' => 0,
                'saved_percent' => 0,
            ));
        }
        
        return $metadata;
    }
    
    /**
     * Filter post thumbnail HTML to output <picture> tag with WebP source
     */
    public static function picture_tag_filter($html, $post_id, $thumbnail_id, $size, $attr) {
        $settings = get_option('bpc_settings', array());
        
        if (empty($settings['picture_tag_output'])) {
            return $html;
        }
        
        if (empty($html)) {
            return $html;
        }
        
        return self::convert_img_to_picture($html, $thumbnail_id, $size);
    }
    
    /**
     * Filter post content to replace <img> with <picture> tags
     */
    public static function content_picture_tag_filter($content) {
        $settings = get_option('bpc_settings', array());
        
        if (empty($settings['picture_tag_output'])) {
            return $content;
        }
        
        // Replace <img> tags in content
        return preg_replace_callback(
            '/<img([^>]+?)\/?>/i',
            function ($matches) {
                $attrs_str = $matches[1];
                // Extract attachment ID from class
                if (preg_match('/wp-image-(\d+)/', $attrs_str, $id_match)) {
                    $attachment_id = intval($id_match[1]);
                    $img_tag = $matches[0];
                    return self::convert_img_to_picture($img_tag, $attachment_id);
                }
                return $matches[0];
            },
            $content
        );
    }
    
    /**
     * Convert an <img> tag to <picture> with WebP source
     */
    private static function convert_img_to_picture($img_html, $attachment_id, $size = 'full') {
        $upload_dir = wp_upload_dir();
        $img_url = wp_get_attachment_image_url($attachment_id, $size);
        
        if (!$img_url) {
            return $img_html;
        }
        
        // Determine WebP URL
        $path_info = pathinfo(parse_url($img_url, PHP_URL_PATH));
        $ext = strtolower($path_info['extension'] ?? '');
        
        // Skip if already WebP/AVIF
        if (in_array($ext, array('webp', 'avif'))) {
            return $img_html;
        }
        
        $webp_url = str_replace('.' . $ext, '.webp', $img_url);
        $webp_path = str_replace('.' . $ext, '.webp', $path_info['dirname'] . '/' . $path_info['basename']);
        
        // Check if WebP version exists on disk
        $webp_full_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $webp_url);
        if (!file_exists($webp_full_path)) {
            return $img_html;
        }
        
        // Extract attributes from original img tag
        $alt = '';
        if (preg_match('/alt=["\']([^"\']*)["\']/', $img_html, $alt_match)) {
            $alt = $alt_match[1];
        }
        
        $class = '';
        if (preg_match('/class=["\']([^"\']*)["\']/', $img_html, $class_match)) {
            $class = $class_match[1];
        }
        
        $width = '';
        if (preg_match('/width=["\']?(\d+)/', $img_html, $w_match)) {
            $width = $w_match[1];
        }
        
        $height = '';
        if (preg_match('/height=["\']?(\d+)/', $img_html, $h_match)) {
            $height = $h_match[1];
        }
        
        $loading = '';
        if (preg_match('/loading=["\']([^"\']*)["\']/', $img_html, $load_match)) {
            $loading = $load_match[1];
        }
        
        // Build <picture> tag
        $picture = '<picture>';
        $picture .= '<source type="image/webp"';
        $picture .= ' srcset="' . esc_url($webp_url) . '"';
        if ($width) $picture .= ' media="(min-width: 1px)"';
        $picture .= '>';
        $picture .= '<img';
        if ($class) $picture .= ' class="' . esc_attr($class) . '"';
        if ($width) $picture .= ' width="' . esc_attr($width) . '"';
        if ($height) $picture .= ' height="' . esc_attr($height) . '"';
        $picture .= ' src="' . esc_url($img_url) . '"';
        $picture .= ' alt="' . esc_attr($alt) . '"';
        if ($loading) $picture .= ' loading="' . esc_attr($loading) . '"';
        $picture .= '>';
        $picture .= '</picture>';
        
        return $picture;
    }
}
