<?php
/**
 * API Client for BulkPicConv
 */

if (!defined('ABSPATH')) {
    exit;
}

class BPC_API {
    
    private $api_url;
    private $api_key;
    
    public function __construct() {
        $settings = get_option('bpc_settings', array());
        $this->api_url = rtrim($settings['api_url'] ?? 'https://www.bulkpicconv.com/api/v1', '/');
        $this->api_key = $settings['api_key'] ?? '';
    }
    
    /**
     * Convert image via API
     * 
     * @param string $image_path Path to the image file
     * @param array $options Conversion options
     * @return array|WP_Error Result with converted image data or error
     */
    public function convert_image($image_path, $options = array()) {
        if (!file_exists($image_path)) {
            return new WP_Error('file_not_found', __('Image file not found.', 'bulkpicconv'));
        }
        
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key is not configured.', 'bulkpicconv'));
        }
        
        $defaults = array(
            'format' => 'webp',
            'quality' => 80,
            'width' => null,
            'height' => null,
        );
        
        $options = wp_parse_args($options, $defaults);
        
        // Prepare multipart request
        $boundary = wp_generate_password(24, false);
        
        $body = '';
        
        // Add image file
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="image"; filename="' . basename($image_path) . '"' . "\r\n";
        $body .= 'Content-Type: ' . mime_content_type($image_path) . "\r\n\r\n";
        $body .= file_get_contents($image_path) . "\r\n";
        
        // Add format
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="format"' . "\r\n\r\n";
        $body .= $options['format'] . "\r\n";
        
        // Add quality
        $body .= '--' . $boundary . "\r\n";
        $body .= 'Content-Disposition: form-data; name="quality"' . "\r\n\r\n";
        $body .= $options['quality'] . "\r\n";
        
        // Add width if specified
        if (!empty($options['width'])) {
            $body .= '--' . $boundary . "\r\n";
            $body .= 'Content-Disposition: form-data; name="width"' . "\r\n\r\n";
            $body .= $options['width'] . "\r\n";
        }
        
        // Add height if specified
        if (!empty($options['height'])) {
            $body .= '--' . $boundary . "\r\n";
            $body .= 'Content-Disposition: form-data; name="height"' . "\r\n\r\n";
            $body .= $options['height'] . "\r\n";
        }
        
        $body .= '--' . $boundary . '--';
        
        $response = wp_remote_post($this->api_url . '/convert', array(
            'timeout' => 60,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
            ),
            'body' => $body,
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            $body = wp_remote_retrieve_body($response);
            $headers = wp_remote_retrieve_headers($response);
            
            return array(
                'data' => $body,
                'content_type' => $headers['content-type'] ?? 'image/webp',
                'input_size' => $headers['x-input-size'] ?? filesize($image_path),
                'output_size' => $headers['x-output-size'] ?? strlen($body),
                'saved_percent' => $headers['x-saved-percent'] ?? 0,
            );
        }
        
        // Handle error
        $error_body = wp_remote_retrieve_body($response);
        $error_data = json_decode($error_body, true);
        $error_message = $error_data['statusMessage'] ?? $error_data['message'] ?? __('API request failed.', 'bulkpicconv');
        
        return new WP_Error('api_error', $error_message, array('status' => $code));
    }
    
    /**
     * Verify license key
     * 
     * @param string $license_key License key to verify
     * @param string $email User email
     * @return array|WP_Error Verification result
     */
    public function verify_license($license_key, $email = '') {
        if (empty($license_key)) {
            return new WP_Error('no_license_key', __('License key is required.', 'bulkpicconv'));
        }
        
        $response = wp_remote_post($this->api_url . '/../license/verify', array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'licenseKey' => $license_key,
                'email' => $email,
            )),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($code === 200 && isset($data['valid']) && $data['valid']) {
            return array(
                'valid' => true,
                'plan' => $data['plan'] ?? 'pro',
                'email' => $data['email'] ?? $email,
                'expiresAt' => $data['expiresAt'] ?? null,
            );
        }
        
        return array(
            'valid' => false,
            'message' => $data['message'] ?? __('Invalid license key.', 'bulkpicconv'),
        );
    }
    
    /**
     * Test API connection
     * 
     * @return bool|WP_Error True on success, error on failure
     */
    public function test_connection() {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key is not configured.', 'bulkpicconv'));
        }
        
        // Create a small test image (1x1 pixel)
        $test_image = imagecreatetruecolor(1, 1);
        ob_start();
        imagepng($test_image);
        $image_data = ob_get_clean();
        imagedestroy($test_image);
        
        // Save to temp file
        $temp_file = wp_tempnam('bpc_test_');
        file_put_contents($temp_file, $image_data);
        
        // Try to convert
        $result = $this->convert_image($temp_file, array('format' => 'webp', 'quality' => 75));
        
        // Clean up
        @unlink($temp_file);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        return true;
    }
    
    /**
     * Get API usage stats
     * 
     * @return array|WP_Error Usage stats or error
     */
    public function get_usage() {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key is not configured.', 'bulkpicconv'));
        }
        
        $response = wp_remote_get($this->api_url . '/../user/api-usage', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
            ),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            return json_decode(wp_remote_retrieve_body($response), true);
        }
        
        return new WP_Error('api_error', __('Failed to get usage stats.', 'bulkpicconv'));
    }
    
    /**
     * Generate AI alt text for an image
     * 
     * @param string $image_path Path to the image file
     * @param string $language Language code (en, zh, es, etc.)
     * @return array|WP_Error Result with alt text or error
     */
    public function generate_alt_text($image_path, $language = 'en') {
        if (!file_exists($image_path)) {
            return new WP_Error('file_not_found', __('Image file not found.', 'bulkpicconv'));
        }
        
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('API key is not configured.', 'bulkpicconv'));
        }
        
        $image_data = file_get_contents($image_path);
        $mime_type = mime_content_type($image_path);
        $base64 = base64_encode($image_data);
        $data_uri = 'data:' . $mime_type . ';base64,' . $base64;
        
        $response = wp_remote_post($this->api_url . '/../v1/ai/alt-text', array(
            'timeout' => 60,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'images' => array($data_uri),
                'language' => $language,
                'style' => 'seo',
            )),
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($code === 200) {
            $data = json_decode($body, true);
            if (!empty($data['success']) && !empty($data['results'][0])) {
                return array(
                    'alt_text' => $data['results'][0]['altText'],
                    'keywords' => $data['results'][0]['keywords'] ?? array(),
                    'confidence' => $data['results'][0]['confidence'] ?? 0,
                );
            }
            return new WP_Error('ai_error', __('Unexpected AI response.', 'bulkpicconv'));
        }
        
        $error_data = json_decode($body, true);
        $error_message = $error_data['error'] ?? __('AI alt text generation failed.', 'bulkpicconv');
        return new WP_Error('ai_error', $error_message);
    }
}
