<?php
/**
 * Settings page for BulkPicConv
 */

if (!defined('ABSPATH')) {
    exit;
}

class BPC_Settings {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('wp_ajax_bpc_test_connection', array(__CLASS__, 'ajax_test_connection'));
        add_action('wp_ajax_bpc_verify_license', array(__CLASS__, 'ajax_verify_license'));
    }
    
    /**
     * Add settings menu
     */
    public static function add_menu() {
        add_options_page(
            __('BulkPicConv - WebP & AVIF Converter', 'bulkpicconv'),
            __('Image Converter', 'bulkpicconv'),
            'manage_options',
            'bulkpicconv',
            array(__CLASS__, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public static function register_settings() {
        register_setting('bpc_settings_group', 'bpc_settings', array(
            'sanitize_callback' => array(__CLASS__, 'sanitize_settings'),
        ));
        
        // API Settings Section
        add_settings_section(
            'bpc_api_section',
            __('API Configuration', 'bulkpicconv'),
            array(__CLASS__, 'render_api_section_desc'),
            'bulkpicconv'
        );
        
        add_settings_field(
            'bpc_api_key',
            __('API Key', 'bulkpicconv'),
            array(__CLASS__, 'render_api_key_field'),
            'bulkpicconv',
            'bpc_api_section'
        );
        
        add_settings_field(
            'bpc_api_url',
            __('API URL', 'bulkpicconv'),
            array(__CLASS__, 'render_api_url_field'),
            'bulkpicconv',
            'bpc_api_section'
        );
        
        // Conversion Settings Section
        add_settings_section(
            'bpc_conversion_section',
            __('Conversion Settings', 'bulkpicconv'),
            array(__CLASS__, 'render_conversion_section_desc'),
            'bulkpicconv'
        );
        
        add_settings_field(
            'bpc_format',
            __('Output Format', 'bulkpicconv'),
            array(__CLASS__, 'render_format_field'),
            'bulkpicconv',
            'bpc_conversion_section'
        );
        
        add_settings_field(
            'bpc_quality',
            __('Quality', 'bulkpicconv'),
            array(__CLASS__, 'render_quality_field'),
            'bulkpicconv',
            'bpc_conversion_section'
        );
        
        add_settings_field(
            'bpc_auto_convert',
            __('Auto Convert', 'bulkpicconv'),
            array(__CLASS__, 'render_auto_convert_field'),
            'bulkpicconv',
            'bpc_conversion_section'
        );
        
        add_settings_field(
            'bpc_auto_alt_text',
            __('AI Alt Text', 'bulkpicconv'),
            array(__CLASS__, 'render_auto_alt_text_field'),
            'bulkpicconv',
            'bpc_conversion_section'
        );
        
        add_settings_field(
            'bpc_picture_tag',
            __('Picture Tag', 'bulkpicconv'),
            array(__CLASS__, 'render_picture_tag_field'),
            'bulkpicconv',
            'bpc_conversion_section'
        );
        
        // License Section
        add_settings_section(
            'bpc_license_section',
            __('License (Optional)', 'bulkpicconv'),
            array(__CLASS__, 'render_license_section_desc'),
            'bulkpicconv'
        );
        
        add_settings_field(
            'bpc_license_key',
            __('License Key', 'bulkpicconv'),
            array(__CLASS__, 'render_license_key_field'),
            'bulkpicconv',
            'bpc_license_section'
        );
    }
    
    /**
     * Sanitize settings
     */
    public static function sanitize_settings($input) {
        $sanitized = array();
        
        $sanitized['api_key'] = sanitize_text_field($input['api_key'] ?? '');
        $sanitized['api_url'] = esc_url_raw($input['api_url'] ?? 'https://www.bulkpicconv.com/api/v1');
        $sanitized['format'] = in_array($input['format'] ?? 'webp', array('webp', 'avif', 'jpeg', 'png')) ? $input['format'] : 'webp';
        $sanitized['quality'] = absint($input['quality'] ?? 80);
        $sanitized['quality'] = max(1, min(100, $sanitized['quality']));
        $sanitized['auto_convert'] = isset($input['auto_convert']) ? true : false;
        $sanitized['auto_alt_text'] = isset($input['auto_alt_text']) ? true : false;
        $sanitized['picture_tag_output'] = isset($input['picture_tag_output']) ? true : false;
        $sanitized['license_key'] = sanitize_text_field($input['license_key'] ?? '');
        
        return $sanitized;
    }
    
    /**
     * Render settings page
     */
    public static function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $settings = get_option('bpc_settings', array());
        $license_status = get_option('bpc_license_status', array());
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="bpc-settings-container">
                <div class="bpc-settings-main">
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('bpc_settings_group');
                        do_settings_sections('bulkpicconv');
                        submit_button(__('Save Settings', 'bulkpicconv'));
                        ?>
                    </form>
                </div>
                
                <div class="bpc-settings-sidebar">
                    <div class="bpc-sidebar-box">
                        <h3><?php _e('Quick Links', 'bulkpicconv'); ?></h3>
                        <ul>
                            <li><a href="https://www.bulkpicconv.com/dashboard" target="_blank"><?php _e('Dashboard', 'bulkpicconv'); ?></a></li>
                            <li><a href="https://www.bulkpicconv.com/api-docs" target="_blank"><?php _e('API Documentation', 'bulkpicconv'); ?></a></li>
                            <li><a href="https://www.bulkpicconv.com/api-pricing" target="_blank"><?php _e('Buy API Credits', 'bulkpicconv'); ?></a></li>
                            <li><a href="https://www.bulkpicconv.com/pro" target="_blank"><?php _e('Upgrade to Pro', 'bulkpicconv'); ?></a></li>
                        </ul>
                    </div>
                    
                    <?php if (!empty($license_status['valid'])): ?>
                    <div class="bpc-sidebar-box bpc-license-active">
                        <h3><?php _e('License Status', 'bulkpicconv'); ?></h3>
                        <p><strong><?php _e('Active', 'bulkpicconv'); ?></strong></p>
                        <p><?php printf(__('Plan: %s', 'bulkpicconv'), esc_html($license_status['plan'] ?? 'Pro')); ?></p>
                        <p><?php printf(__('Email: %s', 'bulkpicconv'), esc_html($license_status['email'] ?? '')); ?></p>
                        <?php if (!empty($license_status['expiresAt'])): ?>
                        <p><?php printf(__('Expires: %s', 'bulkpicconv'), esc_html(date('Y-m-d', strtotime($license_status['expiresAt'])))); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    // Section descriptions
    public static function render_api_section_desc() {
        echo '<p>' . __('Configure your API connection to BulkPicConv service.', 'bulkpicconv') . '</p>';
    }
    
    public static function render_conversion_section_desc() {
        echo '<p>' . __('Set default conversion options for uploaded images.', 'bulkpicconv') . '</p>';
    }
    
    public static function render_license_section_desc() {
        echo '<p>' . __('Enter your Pro license key to share your subscription with this WordPress site. <a href="https://www.bulkpicconv.com/pro" target="_blank">Get a license</a>', 'bulkpicconv') . '</p>';
    }
    
    // Field renderers
    public static function render_api_key_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <input type="password" name="bpc_settings[api_key]" value="<?php echo esc_attr($settings['api_key'] ?? ''); ?>" class="regular-text" />
        <button type="button" class="button bpc-test-connection"><?php _e('Test Connection', 'bulkpicconv'); ?></button>
        <p class="description"><?php _e('Get your API key from the Dashboard.', 'bulkpicconv'); ?></p>
        <?php
    }
    
    public static function render_api_url_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <input type="url" name="bpc_settings[api_url]" value="<?php echo esc_url($settings['api_url'] ?? 'https://www.bulkpicconv.com/api/v1'); ?>" class="regular-text" />
        <p class="description"><?php _e('Default: https://www.bulkpicconv.com/api/v1', 'bulkpicconv'); ?></p>
        <?php
    }
    
    public static function render_format_field() {
        $settings = get_option('bpc_settings', array());
        $format = $settings['format'] ?? 'webp';
        ?>
        <select name="bpc_settings[format]">
            <option value="webp" <?php selected($format, 'webp'); ?>>WebP (<?php _e('Recommended', 'bulkpicconv'); ?>)</option>
            <option value="avif" <?php selected($format, 'avif'); ?>>AVIF (<?php _e('Best compression', 'bulkpicconv'); ?>)</option>
            <option value="jpeg" <?php selected($format, 'jpeg'); ?>>JPEG</option>
            <option value="png" <?php selected($format, 'png'); ?>>PNG</option>
        </select>
        <?php
    }
    
    public static function render_quality_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <input type="number" name="bpc_settings[quality]" value="<?php echo esc_attr($settings['quality'] ?? 80); ?>" min="1" max="100" class="small-text" />
        <p class="description"><?php _e('1-100. Higher = better quality, larger file. Recommended: 75-85.', 'bulkpicconv'); ?></p>
        <?php
    }
    
    public static function render_auto_convert_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <label>
            <input type="checkbox" name="bpc_settings[auto_convert]" value="1" <?php checked($settings['auto_convert'] ?? true, true); ?> />
            <?php _e('Automatically convert images when uploaded to Media Library', 'bulkpicconv'); ?>
        </label>
        <?php
    }
    
    public static function render_auto_alt_text_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <label>
            <input type="checkbox" name="bpc_settings[auto_alt_text]" value="1" <?php checked($settings['auto_alt_text'] ?? false, true); ?> />
            <?php _e('Auto-generate SEO alt text using AI when images are uploaded', 'bulkpicconv'); ?>
        </label>
        <p class="description"><?php _e('Uses GPT-4o Vision to analyze images and generate descriptive alt text. Requires Pro/Team plan or BYOK.', 'bulkpicconv'); ?></p>
        <?php
    }
    
    public static function render_picture_tag_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <label>
            <input type="checkbox" name="bpc_settings[picture_tag_output]" value="1" <?php checked($settings['picture_tag_output'] ?? false, true); ?> />
            <?php _e('Output <picture> tags with WebP source for better browser compatibility', 'bulkpicconv'); ?>
        </label>
        <p class="description"><?php _e('Replaces <img> tags with <picture><source type="image/webp"> + fallback <img>. Only works for images that have been converted to WebP.', 'bulkpicconv'); ?></p>
        <?php
    }
    
    public static function render_license_key_field() {
        $settings = get_option('bpc_settings', array());
        ?>
        <input type="text" name="bpc_settings[license_key]" value="<?php echo esc_attr($settings['license_key'] ?? ''); ?>" class="regular-text" placeholder="bpc_xxxxxxxx" />
        <button type="button" class="button bpc-verify-license"><?php _e('Verify License', 'bulkpicconv'); ?></button>
        <p class="description"><?php _e('Share your Pro subscription across multiple sites.', 'bulkpicconv'); ?></p>
        <?php
    }
    
    /**
     * AJAX: Test API connection
     */
    public static function ajax_test_connection() {
        check_ajax_referer('bpc_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'bulkpicconv'));
        }
        
        $api = new BPC_API();
        $result = $api->test_connection();
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        wp_send_json_success(__('Connection successful!', 'bulkpicconv'));
    }
    
    /**
     * AJAX: Verify license
     */
    public static function ajax_verify_license() {
        check_ajax_referer('bpc_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'bulkpicconv'));
        }
        
        $license_key = sanitize_text_field($_POST['license_key'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        
        if (empty($license_key)) {
            wp_send_json_error(__('License key is required.', 'bulkpicconv'));
        }
        
        $api = new BPC_API();
        $result = $api->verify_license($license_key, $email);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        if ($result['valid']) {
            // Save license status
            update_option('bpc_license_status', array(
                'valid' => true,
                'plan' => $result['plan'],
                'email' => $result['email'],
                'expiresAt' => $result['expiresAt'],
                'verifiedAt' => current_time('mysql'),
            ));
            
            wp_send_json_success(array(
                'message' => __('License verified successfully!', 'bulkpicconv'),
                'plan' => $result['plan'],
                'email' => $result['email'],
            ));
        }
        
        wp_send_json_error($result['message'] ?? __('Invalid license key.', 'bulkpicconv'));
    }
}
