# BulkPicConv - WebP & AVIF Converter (WordPress Plugin)

Automatically convert uploaded images to WebP/AVIF format using the BulkPicConv API. Share your Pro subscription with your WordPress site.

## Features

- **Auto Convert**: Automatically convert images when uploaded to Media Library
- **Multiple Formats**: Support for WebP, AVIF, JPEG, and PNG output
- **Bulk Action**: Convert existing images via Media Library bulk actions
- **License Sharing**: Share your Pro subscription across multiple WordPress sites
- **Attachment Meta Box**: Convert individual images from the attachment edit page
- **🤖 AI Alt Text**: Automatically generate descriptive alt text for uploaded images using AI
- **`<picture>` Tag Output**: Serve WebP with `<picture>` tag fallback for maximum browser compatibility
- **Conversion Log**: Track conversion history and savings

## Requirements

- WordPress 5.0+
- PHP 7.4+
- BulkPicConv API key ([Get one here](https://www.bulkpicconv.com/api-pricing))

## Installation

### Method 1: Upload ZIP

1. Download the plugin ZIP file
2. Go to WordPress Admin → Plugins → Add New → Upload Plugin
3. Choose the ZIP file and click "Install Now"
4. Activate the plugin

### Method 2: Manual Upload

1. Upload `bulkpicconv/` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress

### Method 3: WP-CLI

```bash
wp plugin install bulkpicconv.zip --activate
```

## Configuration

### Basic Setup

1. Go to **Settings → Image Converter**
2. Enter your API Key (get from [Dashboard](https://www.bulkpicconv.com/dashboard))
3. Choose output format (WebP recommended)
4. Set quality (75-85 recommended)
5. Enable "Auto Convert" for automatic conversion
6. Enable "AI Alt Text" to auto-generate descriptions for uploaded images
7. Enable "Picture Tag Output" to serve WebP via `<picture>` tags
8. Click "Save Settings"

### License Sharing (Optional)

If you have a Pro subscription, you can share it with your WordPress site:

1. Go to **Settings → Image Converter**
2. Enter your License Key in the License section
3. Click "Verify License"
4. Your Pro features are now active on this site

## Usage

### Automatic Conversion

When "Auto Convert" is enabled:

- Upload any image to Media Library
- Image is automatically converted to your chosen format
- Original file is replaced with converted version
- Conversion stats are logged

### Bulk Convert Existing Images

1. Go to **Media → Library**
2. Select images to convert
3. Choose "Convert to WebP/AVIF" from Bulk Actions dropdown
4. Click "Apply"
5. Wait for conversion to complete

### Convert Single Image

1. Go to **Media → Library**
2. Click on an image to edit
3. In the "BulkPicConv" meta box (sidebar), click "Convert Now"
4. Wait for conversion to complete

### AI Alt Text

When "AI Alt Text" is enabled:

- Upload any image to Media Library
- AI automatically generates a descriptive alt text
- Alt text is saved to the image's metadata
- Supports multiple languages (configurable)
- Uses 1 API credit per image

### Picture Tag Output

When "Picture Tag Output" is enabled:

- Featured images are automatically wrapped in `<picture>` tags
- Content images (`<img>` in posts) are also converted
- WebP `<source>` is added with the original `<img>` as fallback
- Browsers that support WebP will use the optimized version
- Browsers that don't support WebP will fall back to the original

## API Usage

Each conversion uses 1 API credit. You can:

- **Subscribe to Team/Enterprise plan**: Includes monthly API credits
- **Buy API Credits**: One-time purchase, credits never expire

Check your usage at [Dashboard](https://www.bulkpicconv.com/dashboard).

## Hooks & Filters

### Filters

```php
// Modify conversion options before processing
add_filter('bpc_conversion_options', function($options, $file_path) {
    // Custom logic
    return $options;
}, 10, 2);

// Skip certain files from auto-conversion
add_filter('bpc_skip_auto_convert', function($skip, $file_path) {
    if (strpos($file_path, 'logo') !== false) {
        return true; // Skip files with "logo" in name
    }
    return $skip;
}, 10, 2);
```

### Actions

```php
// After successful conversion
add_action('bpc_after_convert', function($data) {
    // $data contains: original_path, new_path, format, input_size, output_size, saved_percent
    error_log('Converted: ' . $data['original_path'] . ' → ' . $data['new_path']);
});
```

## Troubleshooting

### "API key is not configured"

- Go to Settings → Image Converter
- Enter your API key and save

### "Connection failed"

- Check your API key is correct
- Verify API URL is correct (default: https://www.bulkpicconv.com/api/v1)
- Check server can make outbound HTTPS requests

### Images not converting on upload

- Ensure "Auto Convert" is enabled
- Check file is a supported image type (JPEG, PNG, WebP)
- SVG and GIF are not supported

### "Monthly limit exceeded"

- You've used all API credits for this month
- Purchase more credits at [API Pricing](https://www.bulkpicconv.com/api-pricing)
- Or wait for next month's quota reset

## Changelog

### 1.0.0

- Initial release
- Auto convert on upload
- Bulk action for existing images
- License sharing support
- Attachment meta box conversion

## Support

- [Documentation](https://www.bulkpicconv.com/api-docs)
- [API Pricing](https://www.bulkpicconv.com/api-pricing)
- [Contact Support](https://www.bulkpicconv.com/contact)

## License

GPL v2 or later
