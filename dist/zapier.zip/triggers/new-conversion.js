/**
 * Trigger: New Conversion
 * Polls the batch status API for completed conversions.
 */

const perform = async (z, bundle) => {
  const response = await z.request({
    url: 'https://www.bulkpicconv.com/api/v2/batch/status',
    params: {
      since: bundle.meta.prefetchInterval
        ? new Date(Date.now() - bundle.meta.prefetchInterval * 1000).toISOString()
        : undefined,
    },
  })

  const batches = response.data.batches || []
  return batches
    .filter((b) => b.status === 'completed')
    .map((b) => ({
      id: b.id,
      status: b.status,
      fileCount: b.fileCount,
      completedAt: b.completedAt,
      results: b.results || [],
    }))
}

module.exports = {
  key: 'new_conversion',
  noun: 'Conversion',
  display: {
    label: 'New Conversion Completed',
    description: 'Triggers when a batch image conversion completes.',
  },
  operation: {
    inputFields: [],
    perform,
    sample: {
      id: 'batch_abc123',
      status: 'completed',
      fileCount: 5,
      completedAt: '2025-01-15T10:30:00Z',
      results: [
        {
          filename: 'photo.webp',
          inputSize: 2400000,
          outputSize: 1600000,
          savedPercent: 33,
        },
      ],
    },
  },
}
