# BulkPicConv Zapier Integration

Automate image conversion workflows with Zapier or Make.com.

## Setup

### Zapier

1. Install Zapier CLI: `npm install -g zapier-platform-cli`
2. Register the app: `zapier register "BulkPicConv"`
3. Install dependencies: `npm install`
4. Deploy: `zapier push`

### Make.com

Import the `make-module.json` file into your Make.com custom app configuration.

## Available Integrations

### Trigger: New Conversion Completed

Polls for completed batch conversions. Use this to trigger downstream workflows when images are converted.

### Action: Convert Image

Convert a single image via URL. Supports WebP, AVIF, JPEG, and PNG output with quality/resizing controls.

### Action: Generate AI Alt Text

Generate descriptive alt text for an image using AI. Useful for accessibility (WCAG) and SEO.

**Input fields:**

| Field | Required | Description |
| --- | --- | --- |
| Image URL | Yes | Public URL of the image to analyze |
| Language | No | ISO 639-1 code (en, zh, ja, etc.). Default: en |

**Output:** `alt_text`, `keywords[]`, `confidence`

### Action: Remove Image Background

Remove the background from an image using AI. Returns a transparent PNG by default.

**Input fields:**

| Field | Required | Description |
| --- | --- | --- |
| Image URL | Yes | Public URL of the image |
| Output Format | No | `png` (default) or `webp` |

**Output:** `outputUrl`, `inputSize`, `outputSize`, `format`

## Authentication

Uses API Key authentication. Get your key from [BulkPicConv API Pricing](https://www.bulkpicconv.com/api-pricing).

## Example Workflows

- **E-commerce**: Auto-convert uploaded product images to WebP for faster page loads
- **Social Media**: Convert and resize images for different social platforms
- **CMS Integration**: Auto-optimize images when uploaded to your CMS
- **Accessibility**: Auto-generate alt text for all images using AI
- **Product Photos**: Remove backgrounds from product images automatically
- **Backup Pipeline**: Convert images to AVIF for archival storage

## API Reference

- [BulkPicConv API Docs](https://www.bulkpicconv.com/api-docs)
- [API Pricing](https://www.bulkpicconv.com/api-pricing)
