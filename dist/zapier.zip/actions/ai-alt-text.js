/**
 * Action: AI Generate Alt Text
 * Generates descriptive alt text for images using AI.
 */

const perform = async (z, bundle) => {
  const { imageUrl, language } = bundle.inputData

  const response = await z.request({
    url: 'https://www.bulkpicconv.com/v1/ai/alt-text',
    method: 'POST',
    body: {
      images: [imageUrl],
      language: language || 'en',
    },
  })

  const results = response.data?.data || []
  const first = results[0] || {}

  return {
    alt_text: first.alt_text || '',
    keywords: first.keywords || [],
    confidence: first.confidence || 0,
  }
}

module.exports = {
  key: 'ai_alt_text',
  noun: 'Alt Text',
  display: {
    label: 'Generate AI Alt Text',
    description: 'Generate descriptive alt text for an image using AI. Useful for accessibility and SEO.',
  },
  operation: {
    inputFields: [
      {
        key: 'imageUrl',
        type: 'string',
        required: true,
        label: 'Image URL',
        helpText: 'Public URL of the image to analyze',
      },
      {
        key: 'language',
        type: 'string',
        required: false,
        default: 'en',
        label: 'Language',
        helpText: 'Language for generated text (ISO 639-1 code, e.g. en, zh, ja)',
      },
    ],
    perform,
    sample: {
      alt_text: 'A golden retriever playing fetch on a sunny beach',
      keywords: ['dog', 'beach', 'golden retriever', 'sunny'],
      confidence: 0.95,
    },
  },
}
