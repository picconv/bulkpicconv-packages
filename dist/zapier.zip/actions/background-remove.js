/**
 * Action: Remove Image Background
 * Removes the background from an image and returns the result.
 */

const perform = async (z, bundle) => {
  const { imageUrl, format } = bundle.inputData

  const response = await z.request({
    url: 'https://www.bulkpicconv.com/api/background-remove',
    method: 'POST',
    body: {
      imageUrl,
      format: format || 'png',
    },
  })

  return response.data
}

module.exports = {
  key: 'background_remove',
  noun: 'Background',
  display: {
    label: 'Remove Image Background',
    description: 'Remove the background from an image. Returns a transparent PNG by default.',
  },
  operation: {
    inputFields: [
      {
        key: 'imageUrl',
        type: 'string',
        required: true,
        label: 'Image URL',
        helpText: 'Public URL of the image',
      },
      {
        key: 'format',
        type: 'string',
        required: false,
        default: 'png',
        choices: ['png', 'webp'],
        label: 'Output Format',
        helpText: 'Output format for the result image',
      },
    ],
    perform,
    sample: {
      outputUrl: 'https://cdn.bulkpicconv.com/results/photo-nobg.png',
      inputSize: 2400000,
      outputSize: 800000,
      format: 'png',
    },
  },
}
