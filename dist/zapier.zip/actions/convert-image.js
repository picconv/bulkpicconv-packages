/**
 * Action: Convert Image
 * Converts a single image via the BulkPicConv API.
 */

const perform = async (z, bundle) => {
  const { inputUrl, format, quality, width, height } = bundle.inputData

  const response = await z.request({
    url: 'https://www.bulkpicconv.com/api/v1/convert',
    method: 'POST',
    body: {
      inputUrl,
      format: format || 'webp',
      quality: quality ? Number(quality) : 75,
      width: width ? Number(width) : undefined,
      height: height ? Number(height) : undefined,
    },
  })

  return response.data
}

module.exports = {
  key: 'convert_image',
  noun: 'Image',
  display: {
    label: 'Convert Image',
    description: 'Convert an image to WebP, AVIF, JPEG, or PNG format.',
  },
  operation: {
    inputFields: [
      {
        key: 'inputUrl',
        type: 'string',
        required: true,
        label: 'Input Image URL',
        helpText: 'Public URL of the image to convert',
      },
      {
        key: 'format',
        type: 'string',
        required: true,
        default: 'webp',
        choices: ['webp', 'avif', 'jpeg', 'png'],
        label: 'Output Format',
      },
      {
        key: 'quality',
        type: 'integer',
        required: false,
        default: 75,
        label: 'Quality',
        helpText: '1-100 (default: 75)',
      },
      {
        key: 'width',
        type: 'integer',
        required: false,
        label: 'Max Width (px)',
        helpText: 'Resize to this width, maintaining aspect ratio',
      },
      {
        key: 'height',
        type: 'integer',
        required: false,
        label: 'Max Height (px)',
        helpText: 'Resize to this height, maintaining aspect ratio',
      },
    ],
    perform,
    sample: {
      outputUrl: 'https://cdn.bulkpicconv.com/results/photo.webp',
      inputSize: 2400000,
      outputSize: 1600000,
      savedPercent: 33,
      format: 'webp',
    },
  },
}
