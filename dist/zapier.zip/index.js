/**
 * BulkPicConv Zapier App
 *
 * Provides triggers and actions for integrating BulkPicConv
 * image conversion into Zapier workflows.
 */

const authentication = {
  type: 'custom',
  test: {
    url: 'https://www.bulkpicconv.com/api/health',
    headers: { 'X-API-Key': '{{bundle.authData.apiKey}}' },
  },
  fields: [
    {
      key: 'apiKey',
      type: 'string',
      required: true,
      label: 'API Key',
      helpText: 'Get your API key from https://www.bulkpicconv.com/api-pricing',
    },
  ],
  connectionLabel: '{{bundle.authData.apiKey}}',
}

const newConversion = require('./triggers/new-conversion')
const convertImage = require('./actions/convert-image')
const aiAltText = require('./actions/ai-alt-text')
const backgroundRemove = require('./actions/background-remove')

module.exports = {
  version: require('./package.json').version || '1.0.0',
  platformVersion: '5.0.0',
  authentication,
  triggers: {
    [newConversion.key]: newConversion,
  },
  actions: {
    [convertImage.key]: convertImage,
    [aiAltText.key]: aiAltText,
    [backgroundRemove.key]: backgroundRemove,
  },
}
