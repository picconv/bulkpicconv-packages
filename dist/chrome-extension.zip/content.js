/**
 * Chrome Extension — Content Script
 * 在网页中运行，负责图片抓取和优化处理
 */

// ── 图片处理核心 ──
async function optimizeImage(imgSrc, format = 'webp', quality = 80, maxWidth = 0) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      try {
        let w = img.naturalWidth
        let h = img.naturalHeight

        // 缩放
        if (maxWidth > 0 && w > maxWidth) {
          const scale = maxWidth / w
          w = maxWidth
          h = Math.round(h * scale)
        }

        const canvas = document.createElement('canvas')
        canvas.width = w
        canvas.height = h
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, w, h)

        const mimeType = format === 'avif' ? 'image/avif' : 'image/webp'
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to encode image'))
              return
            }
            // 生成文件名
            const origName = imgSrc.split('/').pop()?.split('?')[0] || 'image'
            const baseName = origName.replace(/\.[^/.]+$/, '')
            const ext = format === 'avif' ? 'avif' : 'webp'
            const filename = `${baseName}-optimized.${ext}`

            const savedPct = imgSrc.startsWith('data:')
              ? 0
              : Math.round((1 - blob.size / (img.naturalWidth * img.naturalHeight * 4)) * 100)

            resolve({
              blob,
              filename,
              originalSize: 0, // 无法准确获取远程文件大小
              convertedSize: blob.size,
              width: w,
              height: h,
              format,
            })
          },
          mimeType,
          quality / 100,
        )
      } catch (err) {
        reject(err)
      }
    }
    img.onerror = () => reject(new Error('Failed to load image'))
    img.src = imgSrc
  })
}

// ── 下载优化后的图片 ──
function downloadOptimized(result) {
  chrome.runtime.sendMessage({
    action: 'download-optimized',
    blob: result.blob,
    filename: result.filename,
  })
}

// ── 显示通知 toast ──
function showToast(message, duration = 3000) {
  // 移除已有 toast
  const existing = document.getElementById('__img_optimizer_toast')
  if (existing) existing.remove()

  const toast = document.createElement('div')
  toast.id = '__img_optimizer_toast'
  toast.textContent = message
  toast.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    background: #0d9488; color: white; padding: 12px 20px;
    border-radius: 8px; font-size: 14px; font-family: system-ui, sans-serif;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: opacity 0.3s; max-width: 360px;
  `
  document.body.appendChild(toast)
  setTimeout(() => {
    toast.style.opacity = '0'
    setTimeout(() => toast.remove(), 300)
  }, duration)
}

// ── 抓取页面所有图片 ──
function grabAllImages() {
  const imgs = Array.from(document.querySelectorAll('img'))
  const seen = new Set()
  const results = []

  for (const img of imgs) {
    const src = img.currentSrc || img.src
    if (!src || src.startsWith('data:') || seen.has(src)) continue

    // 过滤太小的图片（图标、tracking pixel）
    const w = img.naturalWidth || img.width
    const h = img.naturalHeight || img.height
    if (w < 50 || h < 50) continue

    seen.add(src)
    results.push({
      src,
      width: w,
      height: h,
      alt: img.alt || '',
      filename: (src.split('/').pop()?.split('?')[0] || 'image').substring(0, 100),
    })
  }

  return results
}

// ── 消息监听 ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'optimize-single') {
    // 获取设置
    chrome.runtime.sendMessage({ action: 'get-settings' }, async (settings) => {
      const format = msg.format || settings?.format || 'webp'
      const quality = settings?.quality || 80
      const maxWidth = settings?.maxWidth || 0

      showToast('⚡ Optimizing image...')
      try {
        const result = await optimizeImage(msg.srcUrl, format, quality, maxWidth)
        downloadOptimized(result)
        const sizeKB = (result.convertedSize / 1024).toFixed(1)
        showToast(`✅ Optimized: ${result.filename} (${sizeKB} KB)`)
      } catch (err) {
        showToast(`❌ Failed: ${err.message}`)
      }
    })
    sendResponse({ ok: true })
  } else if (msg.action === 'grab-all-images') {
    const images = grabAllImages()
    sendResponse({ images })
  } else if (msg.action === 'ai-alt-text') {
    handleAiAltText(msg.srcUrl)
    sendResponse({ ok: true })
  } else if (msg.action === 'ai-remove-bg') {
    handleAiRemoveBg(msg.srcUrl)
    sendResponse({ ok: true })
  }
  return true
})

// ── AI: Generate Alt Text ──
async function handleAiAltText(srcUrl) {
  showToast('🤖 Generating alt text...')
  try {
    // Fetch image and convert to base64 data URI
    const response = await fetch(srcUrl)
    const blob = await response.blob()
    const base64 = await blobToBase64(blob)

    const apiRes = await fetch('https://www.bulkpicconv.com/v1/ai/alt-text', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ images: [base64] }),
    })
    const data = await apiRes.json()
    const altText = data?.data?.[0]?.alt_text || 'No description generated'

    // Copy to clipboard
    await navigator.clipboard.writeText(altText)
    showToast(`🤖 Alt text copied to clipboard:\n"${altText.substring(0, 80)}"`, 5000)
  } catch (err) {
    showToast(`❌ AI Alt Text failed: ${err.message}`)
  }
}

// ── AI: Remove Background ──
async function handleAiRemoveBg(srcUrl) {
  showToast('✂️ Removing background...')
  try {
    const response = await fetch(srcUrl)
    const blob = await response.blob()

    const formData = new FormData()
    formData.append('image', blob, 'image.png')

    const apiRes = await fetch('https://www.bulkpicconv.com/api/background-remove', {
      method: 'POST',
      body: formData,
    })
    const resultBlob = await apiRes.blob()

    // Download the result
    const reader = new FileReader()
    reader.onload = () => {
      chrome.runtime.sendMessage({
        action: 'download-optimized',
        blob: resultBlob,
        filename: 'no-background.png',
      })
    }
    reader.readAsDataURL(resultBlob)

    const sizeKB = (resultBlob.size / 1024).toFixed(1)
    showToast(`✅ Background removed (${sizeKB} KB)`)
  } catch (err) {
    showToast(`❌ Background removal failed: ${err.message}`)
  }
}

// ── Helper: Blob to Base64 ──
function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(blob)
  })
}
