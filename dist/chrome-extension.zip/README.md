# Bulk Image Optimizer — Chrome Extension

右键优化任意图片为 WebP/AVIF，一键抓取页面所有图片批量优化。100% 本地处理，不上传。

## 功能

- **右键优化单张图片** — 右键任意图片 → "Optimize this image (WebP/AVIF)"
- **抓取页面全部图片** — 右键页面 → "Grab all images on page"
- **批量优化下载** — Popup 中选择图片，一键优化并批量下载
- **🤖 AI 生成 Alt Text** — 右键图片 → "Generate AI Alt Text"，自动描述图片内容并复制到剪贴板
- **✂️ AI 去除背景** — 右键图片 → "Remove Background (AI)"，自动去除背景并下载
- **AI Tools 面板** — Popup 新增 AI Tools 标签页，可直接对页面首图执行 AI 操作
- **自定义设置** — 格式（WebP/AVIF）、质量、最大宽度
- **100% 本地处理** — 基础优化使用 Canvas API，AI 功能调用云端 API

## 安装

### 开发者模式安装

1. 打开 Chrome，访问 `chrome://extensions/`
2. 开启右上角「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择 `chrome-extension/` 目录
5. 扩展已安装完成
6. 首次安装会自动打开欢迎页，展示所有功能使用说明

### 生成图标

扩展需要 3 个尺寸的图标（16x16, 48x48, 128x128）。

可以用任意图片编辑工具生成，或使用在线工具。将生成的 PNG 放入 `icons/` 目录：

- `icons/icon16.png`
- `icons/icon48.png`
- `icons/icon128.png`

> 提示：如果没有图标文件，扩展仍可加载但会显示默认图标。

## 使用方法

### 右键优化单张图片

1. 在任意网页上右键一张图片
2. 选择「⚡ Optimize this image (WebP)」或「⚡ Optimize this image (AVIF)」
3. 图片自动优化并下载到 `optimized/` 文件夹

### 抓取页面全部图片

1. 在任意网页上右键（非图片区域）
2. 选择「📦 Grab all images on page」
3. 点击扩展图标打开 Popup
4. 切换到「Grabbed」标签页
5. 选择要优化的图片
6. 点击「Optimize Selected」批量优化下载

### 设置

在 Popup 的「Settings」标签页中配置：

- **Format**: WebP（推荐）或 AVIF（最佳压缩率）
- **Quality**: 10-100，推荐 80
- **Max width**: 0 = 不限制，设置后自动缩小超出宽度的图片

### AI 工具

#### 右键菜单 AI 操作

1. 在任意网页上右键一张图片
2. 选择「🤖 Generate AI Alt Text」→ 自动生成图片描述并复制到剪贴板
3. 或选择「✂️ Remove Background (AI)」→ 自动去除背景并下载透明 PNG

> AI 功能需要 BulkPicConv Pro 订阅，图片会上传到服务器进行 AI 处理。

#### Popup AI Tools 面板

1. 点击扩展图标打开 Popup
2. 切换到「AI Tools」标签页
3. 点击「🤖 Generate Alt Text」或「✂️ Remove Background」
4. 工具会自动处理当前页面第一张图片
5. Alt Text 结果自动复制到剪贴板，Background 结果自动下载

## 技术栈

- Manifest V3（最新 Chrome 扩展标准）
- Canvas API 图片处理
- Chrome Storage API 持久化设置
- Chrome Downloads API 批量下载

## 权限说明

| 权限 | 用途 |
| --- | --- |
| `contextMenus` | 右键菜单操作 |
| `activeTab` | 访问当前标签页图片 |
| `downloads` | 下载优化后的图片 |
| `storage` | 保存设置和抓取结果 |
| `clipboardWrite` | AI Alt Text 结果复制到剪贴板 |

## 与主项目的关系

此扩展是 [BulkPicConv](https://www.bulkpicconv.com) 的浏览器 companion。

- 扩展：轻量级，Canvas API 处理，适合快速优化
- 主站：完整功能，支持 WASM 编码、编辑（裁剪/水印/滤镜）、工作流等
