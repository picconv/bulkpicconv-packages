/**
 * Chrome Extension — Background Service Worker
 * 处理右键菜单、消息传递和下载管理
 */

// ── 右键菜单 ──
chrome.runtime.onInstalled.addListener((details) => {
  // 首次安装时打开欢迎页
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') })
  }

  chrome.contextMenus.create({
    id: 'optimize-image',
    title: '⚡ Optimize this image (WebP)',
    contexts: ['image'],
  })
  chrome.contextMenus.create({
    id: 'optimize-image-avif',
    title: '⚡ Optimize this image (AVIF)',
    contexts: ['image'],
  })
  chrome.contextMenus.create({
    id: 'grab-all-images',
    title: '📦 Grab all images on page',
    contexts: ['page'],
  })
  chrome.contextMenus.create({
    id: 'ai-alt-text',
    title: '🤖 Generate AI Alt Text',
    contexts: ['image'],
  })
  chrome.contextMenus.create({
    id: 'ai-remove-bg',
    title: '✂️ Remove Background (AI)',
    contexts: ['image'],
  })
})

// ── 菜单点击处理 ──
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return

  if (info.menuItemId === 'optimize-image') {
    // 优化单张图片 → 通知 content script 获取图片并处理
    chrome.tabs.sendMessage(tab.id, {
      action: 'optimize-single',
      srcUrl: info.srcUrl,
    })
  } else if (info.menuItemId === 'optimize-image-avif') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'optimize-single',
      srcUrl: info.srcUrl,
      format: 'avif',
    })
  } else if (info.menuItemId === 'grab-all-images') {
    // 抓取页面所有图片
    chrome.tabs.sendMessage(tab.id, { action: 'grab-all-images' }, (response) => {
      if (response?.images?.length) {
        // 存储图片列表，供 popup 使用
        chrome.storage.local.set({
          grabbedImages: response.images,
          grabbedAt: Date.now(),
          pageUrl: tab.url,
          pageTitle: tab.title,
        })
        // 打开 popup 提示（如果可能）
        chrome.action.setBadgeText({ text: String(response.images.length), tabId: tab.id })
        chrome.action.setBadgeBackgroundColor({ color: '#0d9488', tabId: tab.id })
      }
    })
  } else if (info.menuItemId === 'ai-alt-text') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'ai-alt-text',
      srcUrl: info.srcUrl,
    })
  } else if (info.menuItemId === 'ai-remove-bg') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'ai-remove-bg',
      srcUrl: info.srcUrl,
    })
  }
})

// ── 来自 content script 的消息 ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'download-optimized') {
    // 下载优化后的图片
    const blob = msg.blob
    const filename = msg.filename || 'optimized.webp'

    // 将 blob 转为 data URL 用于下载
    const reader = new FileReader()
    reader.onload = () => {
      chrome.downloads.download({
        url: reader.result,
        filename: `optimized/${filename}`,
        saveAs: false,
      })
    }
    reader.readAsDataURL(blob)
    sendResponse({ success: true })
  } else if (msg.action === 'get-settings') {
    chrome.storage.local.get(['format', 'quality', 'maxWidth'], (data) => {
      sendResponse({
        format: data.format || 'webp',
        quality: data.quality || 80,
        maxWidth: data.maxWidth || 0,
      })
    })
    return true // async
  } else if (msg.action === 'save-settings') {
    chrome.storage.local.set(msg.settings)
    sendResponse({ success: true })
  } else if (msg.action === 'batch-download') {
    // 批量下载
    const items = msg.items || []
    items.forEach((item, i) => {
      setTimeout(() => {
        const reader = new FileReader()
        reader.onload = () => {
          chrome.downloads.download({
            url: reader.result,
            filename: `optimized/${item.filename}`,
            saveAs: false,
          })
        }
        reader.readAsDataURL(item.blob)
      }, i * 200) // 间隔 200ms 避免触发下载限制
    })
    sendResponse({ success: true })
  }
  return true
})

// ── 清除 badge ──
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete') {
    chrome.action.setBadgeText({ text: '', tabId })
  }
})
