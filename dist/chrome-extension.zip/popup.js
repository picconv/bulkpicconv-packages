/**
 * Chrome Extension — Popup Script
 * 设置管理 + 抓取图片批量优化
 */

// ── DOM 元素 ──
const formatEl = document.getElementById('format')
const qualityEl = document.getElementById('quality')
const qualityValEl = document.getElementById('quality-val')
const maxWidthEl = document.getElementById('maxWidth')
const saveBtn = document.getElementById('save-settings')
const grabbedListEl = document.getElementById('grabbed-list')
const grabbedCountEl = document.getElementById('grabbed-count')
const optimizeAllBtn = document.getElementById('optimize-all')
const reGrabBtn = document.getElementById('re-grab')
const progressBarEl = document.getElementById('progress-bar')
const progressFillEl = document.getElementById('progress-fill')
const statusEl = document.getElementById('status')

// ── Tab 切换 ──
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'))
    tab.classList.add('active')
    const target = tab.dataset.tab
    document.getElementById('tab-settings').classList.toggle('hidden', target !== 'settings')
    document.getElementById('tab-grabbed').classList.toggle('hidden', target !== 'grabbed')
    document.getElementById('tab-ai').classList.toggle('hidden', target !== 'ai')
  })
})

// ── 加载设置 ──
chrome.storage.local.get(['format', 'quality', 'maxWidth'], (data) => {
  if (data.format) formatEl.value = data.format
  if (data.quality) {
    qualityEl.value = data.quality
    qualityValEl.textContent = data.quality + '%'
  }
  if (data.maxWidth) maxWidthEl.value = data.maxWidth
})

// ── Quality 滑块实时显示 ──
qualityEl.addEventListener('input', () => {
  qualityValEl.textContent = qualityEl.value + '%'
})

// ── 保存设置 ──
saveBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({
    action: 'save-settings',
    settings: {
      format: formatEl.value,
      quality: Number(qualityEl.value),
      maxWidth: Number(maxWidthEl.value) || 0,
    },
  })
  saveBtn.textContent = '✓ Saved!'
  setTimeout(() => {
    saveBtn.textContent = 'Save Settings'
  }, 1500)
})

// ── 加载已抓取图片 ──
let grabbedImages = []

function loadGrabbedImages() {
  chrome.storage.local.get(['grabbedImages'], (data) => {
    grabbed_images = data.grabbedImages || []
    renderGrabbedList()
  })
}

function renderGrabbedList() {
  if (grabbed_images.length === 0) {
    grabbedListEl.textContent = ''
    const empty = document.createElement('div')
    empty.className = 'empty'
    empty.textContent = 'No images grabbed yet. Right-click a page \u2192 "Grab all images"'
    grabbedListEl.appendChild(empty)
    grabbedCountEl.textContent = ''
    optimizeAllBtn.disabled = true
    return
  }

  grabbedCountEl.textContent = `(${grabbed_images.length})`
  grabbedListEl.innerHTML = ''

  grabbed_images.forEach((img, i) => {
    const item = document.createElement('div')
    item.className = 'grabbed-item'

    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.checked = true
    checkbox.dataset.index = String(i)

    const thumb = document.createElement('img')
    thumb.src = img.src
    thumb.loading = 'lazy'
    thumb.onerror = () => {
      thumb.style.display = 'none'
    }

    const info = document.createElement('div')
    info.className = 'info'

    const nameEl = document.createElement('div')
    nameEl.className = 'name'
    nameEl.textContent = img.filename || 'image-' + i

    const metaEl = document.createElement('div')
    metaEl.className = 'meta'
    metaEl.textContent = `${img.width}\u00d7${img.height}`

    info.appendChild(nameEl)
    info.appendChild(metaEl)
    item.appendChild(checkbox)
    item.appendChild(thumb)
    item.appendChild(info)
    grabbedListEl.appendChild(item)
  })

  optimizeAllBtn.disabled = false
}

// ── 重新抓取 ──
reGrabBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.id) return

  chrome.tabs.sendMessage(tab.id, { action: 'grab-all-images' }, (response) => {
    if (response?.images?.length) {
      grabbed_images = response.images
      chrome.storage.local.set({ grabbedImages: response.images })
      renderGrabbedList()
    }
  })
})

// ── 批量优化 ──
optimizeAllBtn.addEventListener('click', async () => {
  const checkboxes = grabbedListEl.querySelectorAll('input[type="checkbox"]:checked')
  if (checkboxes.length === 0) return

  const settings = {
    format: formatEl.value,
    quality: Number(qualityEl.value),
    maxWidth: Number(maxWidthEl.value) || 0,
  }

  optimizeAllBtn.disabled = true
  optimizeAllBtn.textContent = 'Optimizing...'
  progressBarEl.classList.remove('hidden')
  statusEl.classList.remove('hidden')

  const indices = Array.from(checkboxes).map((cb) => Number(cb.dataset.index))
  let completed = 0
  const total = indices.length
  const results = []

  for (const idx of indices) {
    const img = grabbed_images[idx]
    if (!img) continue

    statusEl.textContent = `Optimizing ${completed + 1}/${total}...`
    progressFillEl.style.width = `${(completed / total) * 100}%`

    try {
      const result = await optimizeInPopup(img.src, settings)
      results.push({ blob: result.blob, filename: result.filename })
      completed++
    } catch (err) {
      console.error('Failed to optimize:', img.filename, err)
      completed++
    }

    progressFillEl.style.width = `${(completed / total) * 100}%`
  }

  // 批量下载
  if (results.length > 0) {
    chrome.runtime.sendMessage({
      action: 'batch-download',
      items: results,
    })
  }

  statusEl.textContent = `✅ ${results.length}/${total} images optimized and downloaded!`
  optimizeAllBtn.textContent = 'Optimize Selected'
  optimizeAllBtn.disabled = false

  setTimeout(() => {
    progressBarEl.classList.add('hidden')
    statusEl.classList.add('hidden')
  }, 5000)
})

// ── Popup 内图片处理 ──
function optimizeInPopup(src, settings) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => {
      let w = img.naturalWidth
      let h = img.naturalHeight

      if (settings.maxWidth > 0 && w > settings.maxWidth) {
        const scale = settings.maxWidth / w
        w = settings.maxWidth
        h = Math.round(h * scale)
      }

      const canvas = document.createElement('canvas')
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0, w, h)

      const mimeType = settings.format === 'avif' ? 'image/avif' : 'image/webp'
      canvas.toBlob(
        (blob) => {
          if (!blob) return reject(new Error('Encode failed'))
          const baseName =
            src
              .split('/')
              .pop()
              ?.split('?')[0]
              ?.replace(/\.[^/.]+$/, '') || 'image'
          const ext = settings.format === 'avif' ? 'avif' : 'webp'
          resolve({ blob, filename: `${baseName}-optimized.${ext}` })
        },
        mimeType,
        settings.quality / 100,
      )
    }
    img.onerror = () => reject(new Error('Load failed'))
    img.src = src
  })
}

// ── 初始化 ──
loadGrabbedImages()

// ── AI Tools ──
const aiStatusEl = document.getElementById('ai-status')
const aiAltTextBtn = document.getElementById('ai-alt-text-btn')
const aiRemoveBgBtn = document.getElementById('ai-remove-bg-btn')

function showAiStatus(msg, isError = false) {
  aiStatusEl.textContent = msg
  aiStatusEl.style.color = isError ? '#ef4444' : '#64748b'
}

aiAltTextBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.id) return

  showAiStatus('🤖 Generating alt text for first image on page...')
  // Find first image on the page via content script
  chrome.tabs.sendMessage(tab.id, { action: 'grab-all-images' }, async (response) => {
    const imgs = response?.images || []
    if (imgs.length === 0) {
      showAiStatus('No images found on this page.', true)
      return
    }
    try {
      showAiStatus('🤖 Analyzing image...')
      const imgSrc = imgs[0].src
      const imgResponse = await fetch(imgSrc)
      const blob = await imgResponse.blob()
      const base64 = await new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => resolve(reader.result)
        reader.onerror = reject
        reader.readAsDataURL(blob)
      })

      const apiRes = await fetch('https://www.bulkpicconv.com/v1/ai/alt-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ images: [base64] }),
      })
      const data = await apiRes.json()
      const altText = data?.data?.[0]?.alt_text || 'No description generated'

      // Copy to clipboard
      await navigator.clipboard.writeText(altText)
      showAiStatus(`✅ Alt text copied: "${altText.substring(0, 60)}"`)
    } catch (err) {
      showAiStatus(`❌ Failed: ${err.message}`, true)
    }
  })
})

aiRemoveBgBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.id) return

  showAiStatus('✂️ Finding image to process...')
  chrome.tabs.sendMessage(tab.id, { action: 'grab-all-images' }, async (response) => {
    const imgs = response?.images || []
    if (imgs.length === 0) {
      showAiStatus('No images found on this page.', true)
      return
    }
    try {
      showAiStatus('✂️ Removing background...')
      const imgSrc = imgs[0].src
      const imgResponse = await fetch(imgSrc)
      const blob = await imgResponse.blob()

      const formData = new FormData()
      formData.append('image', blob, 'image.png')

      const apiRes = await fetch('https://www.bulkpicconv.com/api/background-remove', {
        method: 'POST',
        body: formData,
      })
      const resultBlob = await apiRes.blob()

      // Download via background script
      const reader = new FileReader()
      reader.onload = () => {
        chrome.runtime.sendMessage({
          action: 'batch-download',
          items: [{ blob: resultBlob, filename: 'no-background.png' }],
        })
        showAiStatus(`✅ Background removed (${(resultBlob.size / 1024).toFixed(1)} KB)`)
      }
      reader.readAsDataURL(resultBlob)
    } catch (err) {
      showAiStatus(`❌ Failed: ${err.message}`, true)
    }
  })
})
