#!/usr/bin/env node

/**
 * BulkPicConv CLI - Batch image conversion via BulkPicConv API
 *
 * Zero-dependency (uses the SDK via relative import).
 * Requires Node.js 18+.
 */

import { BulkPicConv } from '../sdk/node/index.js'
import { readFile, readdir, mkdir, stat } from 'node:fs/promises'
import { basename, dirname, extname, join, resolve } from 'node:path'

const VERSION = '1.0.0'
const IMAGE_EXTENSIONS = new Set([
  '.jpg',
  '.jpeg',
  '.png',
  '.webp',
  '.avif',
  '.gif',
  '.bmp',
  '.tif',
  '.tiff',
  '.heic',
  '.heif',
])
const VALID_FORMATS = ['webp', 'avif', 'jpeg', 'png']
const FORMAT_EXT = { webp: 'webp', avif: 'avif', jpeg: 'jpg', png: 'png' }

// ---------------------------------------------------------------------------
// Argument parsing
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const args = argv.slice(2)
  let command = null
  const flags = {}
  const positional = []

  for (let i = 0; i < args.length; i++) {
    const arg = args[i]

    if (arg === '--') {
      positional.push(...args.slice(i + 1))
      break
    }

    if (arg.startsWith('--')) {
      const eqIdx = arg.indexOf('=')
      if (eqIdx > 2) {
        flags[arg.slice(2, eqIdx)] = arg.slice(eqIdx + 1)
      } else {
        const key = arg.slice(2)
        const next = args[i + 1]
        if (next !== undefined && !next.startsWith('-')) {
          flags[key] = next
          i++
        } else {
          flags[key] = 'true'
        }
      }
    } else if (arg.startsWith('-') && arg.length > 1) {
      const eqIdx = arg.indexOf('=')
      if (eqIdx > 1) {
        flags[arg.slice(1, eqIdx)] = arg.slice(eqIdx + 1)
      } else {
        const key = arg.slice(1)
        const next = args[i + 1]
        if (next !== undefined && !next.startsWith('-')) {
          flags[key] = next
          i++
        } else {
          flags[key] = 'true'
        }
      }
    } else {
      if (command === null) {
        command = arg
      } else {
        positional.push(arg)
      }
    }
  }

  return { command, flags, positional }
}

// ---------------------------------------------------------------------------
// Minimal glob expansion (no external dependencies)
// ---------------------------------------------------------------------------

const GLOB_CHARS = /[*?[\]]/

async function expandGlob(pattern) {
  pattern = pattern.replace(/\\/g, '/')

  if (!GLOB_CHARS.test(pattern)) {
    try {
      const info = await stat(pattern)
      if (info.isDirectory()) return collectImageFiles(pattern)
    } catch {
      return []
    }
    return [pattern]
  }

  const segments = pattern.split('/')
  const baseSegs = []
  let i = 0
  while (i < segments.length && !GLOB_CHARS.test(segments[i]) && segments[i] !== '**') {
    baseSegs.push(segments[i])
    i++
  }

  let baseDir
  if (baseSegs.length === 1 && baseSegs[0] === '') {
    baseDir = '/'
  } else if (baseSegs.length === 0) {
    baseDir = '.'
  } else {
    baseDir = baseSegs.join('/')
  }

  const results = []
  await walkGlob(baseDir, segments.slice(i), results)
  return results.sort()
}

async function collectImageFiles(dir) {
  const results = []
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return results
  }
  for (const entry of entries) {
    const path = join(dir, entry.name)
    if (entry.isDirectory()) {
      results.push(...(await collectImageFiles(path)))
    } else if (IMAGE_EXTENSIONS.has(extname(entry.name).toLowerCase())) {
      results.push(path)
    }
  }
  return results.sort()
}

async function findConfig(startDir) {
  let current = resolve(startDir)
  while (true) {
    const path = join(current, '.bulkpicconvrc')
    try {
      return JSON.parse(await readFile(path, 'utf8'))
    } catch {
      const parent = dirname(current)
      if (parent === current) return {}
      current = parent
    }
  }
}

function flagValue(flags, config, key, envKey, fallback) {
  return flags[key] !== undefined
    ? flags[key]
    : config[key] !== undefined
      ? config[key]
      : process.env[envKey] || fallback
}

function collectOptionFlags(flags, config, positionals) {
  const firstInput = positionals[0] || '.'
  return {
    format: flagValue(flags, config, 'format', 'BULKPICCONV_FORMAT', 'webp'),
    quality: flagValue(flags, config, 'quality', 'BULKPICCONV_QUALITY', 75),
    width: flagValue(flags, config, 'width', 'BULKPICCONV_WIDTH', undefined),
    height: flagValue(flags, config, 'height', 'BULKPICCONV_HEIGHT', undefined),
    output: flagValue(flags, config, 'output', 'BULKPICCONV_OUTPUT', '.'),
    apiKey: flagValue(flags, config, 'api-key', 'BULKPICCONV_API_KEY', undefined),
    baseUrl: flagValue(flags, config, 'base-url', 'BULKPICCONV_BASE_URL', 'https://www.bulkpicconv.com'),
    timeout: flagValue(flags, config, 'timeout', 'BULKPICCONV_TIMEOUT', 30000),
    maxRetries: flagValue(flags, config, 'max-retries', 'BULKPICCONV_MAX_RETRIES', 2),
    configStart: dirname(resolve(firstInput)),
  }
}

async function walkGlob(dir, segments, results) {
  if (segments.length === 0) {
    results.push(dir)
    return
  }

  const [seg, ...rest] = segments

  if (seg === '**') {
    await walkGlob(dir, rest, results)
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      if (entry.isDirectory()) {
        await walkGlob(join(dir, entry.name), segments, results)
      }
    }
    return
  }

  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return
  }

  if (GLOB_CHARS.test(seg)) {
    const regex = wildcardToRegex(seg)
    for (const entry of entries) {
      if (regex.test(entry.name)) {
        await walkGlob(join(dir, entry.name), rest, results)
      }
    }
  } else {
    await walkGlob(join(dir, seg), rest, results)
  }
}

function wildcardToRegex(seg) {
  let regex = '^'
  for (let i = 0; i < seg.length; i++) {
    const c = seg[i]
    if (c === '*') {
      regex += '[^/]*'
    } else if (c === '?') {
      regex += '[^/]'
    } else if (c === '[') {
      regex += '['
      i++
      if (i < seg.length && seg[i] === '!') {
        regex += '^'
        i++
      }
      while (i < seg.length && seg[i] !== ']') {
        regex += seg[i]
        i++
      }
      regex += ']'
    } else if ('.+^${}()|\\'.includes(c)) {
      regex += '\\' + c
    } else {
      regex += c
    }
  }
  return new RegExp(regex + '$')
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function outputFilename(inputPath, format) {
  const ext = FORMAT_EXT[format] || format
  const base = basename(inputPath, extname(inputPath))
  return `${base}.${ext}`
}

function renderProgress(current, total) {
  const width = 30
  const ratio = total > 0 ? current / total : 1
  const filled = Math.round(ratio * width)
  const bar = '#'.repeat(filled) + '-'.repeat(width - filled)
  const percent = Math.round(ratio * 100)
  process.stdout.write(`\rConverting  [${bar}] ${current}/${total}  ${percent}%`)
  if (current === total) {
    process.stdout.write('\n')
  }
}

function printHelp() {
  console.log(`
BulkPicConv CLI v${VERSION}

Usage:
  bulkpicconv convert <input...> [options]

Commands:
  convert     Convert one or more images
  activate    Activate a Pro license key

Options:
  --format <fmt>      Output format: webp, avif, jpeg, png (default: webp)
  --quality <n>       Quality 1-100 (default: 75)
  --width <n>         Output width in pixels
  --height <n>        Output height in pixels
  -o, --output <dir>  Output directory (default: current directory)
  --api-key <key>     API key (or env: BULKPICCONV_API_KEY)
  --base-url <url>    API base URL (or env: BULKPICCONV_BASE_URL)
  --timeout <ms>      Request timeout (default: 30000)
  --max-retries <n>   Maximum transient retries (default: 2)
  .bulkpicconvrc      JSON config; CLI flags override config values
  -v, --version       Show version

License Activation:
  bulkpicconv activate <license-key>
  Activates your Pro license. After activation, conversions run with
  Pro features (no watermark, high quality, all formats).

Examples:
  bulkpicconv convert photo.jpg --format webp --quality 80
  bulkpicconv convert *.jpg --format avif --quality 75 --output ./dist/
  bulkpicconv convert ./images/**/*.png --format webp -o ./optimized/
`)
}

// ---------------------------------------------------------------------------
// License Activation
// ---------------------------------------------------------------------------

const LICENSE_FILE = '.bulkpicconv-license'

async function activateLicense(key, flags) {
  if (!key) {
    console.error('Error: license key required. Usage: bulkpicconv activate <license-key>')
    process.exit(1)
  }

  const baseUrl = flags['base-url'] || process.env.BULKPICCONV_BASE_URL || 'https://www.bulkpicconv.com'
  const timeout = Number(flags.timeout || 15000)

  console.log(`Activating license...`)

  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeout)

    const res = await fetch(`${baseUrl}/api/license/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key }),
      signal: controller.signal,
    })
    clearTimeout(timer)

    if (!res.ok) {
      const body = await res.json().catch(() => ({}))
      throw new Error(body.message || `Server returned ${res.status}`)
    }

    const data = await res.json()
    if (!data.valid) {
      throw new Error(data.reason || 'License key is invalid')
    }

    // Save license key locally
    const { writeFile } = await import('node:fs/promises')
    const licensePath = join(process.env.HOME || process.env.USERPROFILE || '.', LICENSE_FILE)
    await writeFile(
      licensePath,
      JSON.stringify({ key, activatedAt: new Date().toISOString(), plan: data.plan || 'pro' }),
    )

    console.log(`License activated successfully!`)
    console.log(`  Plan: ${data.plan || 'pro'}`)
    console.log(`  Saved to: ${licensePath}`)
    console.log(`\nPro features are now enabled. Run conversions with --api-key to use Pro capabilities.`)
  } catch (err) {
    console.error(`Activation failed: ${err.message}`)
    process.exit(1)
  }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const { command, flags, positional } = parseArgs(process.argv)

  if (flags.help || flags.h) {
    printHelp()
    return
  }

  if (flags.version || flags.v) {
    console.log(VERSION)
    return
  }

  if (command === 'activate') {
    await activateLicense(positional[0], flags)
    return
  }

  if (command !== 'convert') {
    printHelp()
    process.exit(1)
  }

  // Resolve configuration and options
  const config = await findConfig(process.cwd())
  const options = collectOptionFlags(flags, config, positional)

  const apiKey = options.apiKey
  if (!apiKey) {
    console.error('Error: API key required. Use --api-key or set BULKPICCONV_API_KEY env var.')
    process.exit(1)
  }

  const baseUrl = options.baseUrl

  // Parse format
  const format = String(options.format)
  if (!VALID_FORMATS.includes(format)) {
    console.error(`Error: invalid format "${format}". Valid: ${VALID_FORMATS.join(', ')}`)
    process.exit(1)
  }

  // Parse quality
  const quality = Number(options.quality)
  if (Number.isNaN(quality) || quality < 1 || quality > 100) {
    console.error('Error: quality must be a number between 1 and 100')
    process.exit(1)
  }

  // Parse dimensions
  const width = options.width !== undefined ? Number(options.width) : undefined
  const height = options.height !== undefined ? Number(options.height) : undefined
  if (width !== undefined && (Number.isNaN(width) || width < 1)) {
    console.error('Error: width must be a positive number')
    process.exit(1)
  }
  if (height !== undefined && (Number.isNaN(height) || height < 1)) {
    console.error('Error: height must be a positive number')
    process.exit(1)
  }

  const timeout = Number(options.timeout)
  const maxRetries = Number(options.maxRetries)
  if (Number.isNaN(timeout) || timeout < 0 || Number.isNaN(maxRetries) || maxRetries < 0) {
    console.error('Error: timeout and max-retries must be non-negative numbers')
    process.exit(1)
  }

  const outputDir = options.output

  // Expand glob patterns and directories
  const allInputs = []
  for (const pattern of positional) {
    const matches = await expandGlob(pattern)
    allInputs.push(...matches)
  }
  const uniqueInputs = [...new Set(allInputs)]

  if (uniqueInputs.length === 0) {
    console.error('Error: no input files found.')
    process.exit(1)
  }

  // Create output directory
  await mkdir(outputDir, { recursive: true })

  const client = new BulkPicConv({ apiKey, baseUrl, timeout, maxRetries })

  // Process files
  const results = []
  const total = uniqueInputs.length

  renderProgress(0, total)

  for (let i = 0; i < total; i++) {
    const inputPath = uniqueInputs[i]
    const outputPath = join(outputDir, outputFilename(inputPath, format))

    try {
      const result = await client.convertFile(inputPath, outputPath, { format, quality, width, height })
      results.push({ inputPath, outputPath, ...result, error: null })
    } catch (err) {
      results.push({ inputPath, outputPath, error: err.message, outputSize: 0, inputSize: 0, savedPercent: 0 })
    }

    renderProgress(i + 1, total)
  }

  // Print summary
  console.log('')

  let totalInput = 0
  let totalOutput = 0
  let successCount = 0
  let failCount = 0

  for (const r of results) {
    if (r.error) {
      console.log(`  \u2717 ${r.inputPath} - ${r.error}`)
      failCount++
    } else {
      const verb = r.savedPercent >= 0 ? 'saved' : 'increased'
      console.log(
        `  \u2713 ${r.inputPath} -> ${r.outputPath}  ${formatBytes(r.inputSize)} -> ${formatBytes(r.outputSize)}  ${verb} ${Math.abs(r.savedPercent)}%`,
      )
      totalInput += r.inputSize
      totalOutput += r.outputSize
      successCount++
    }
  }

  console.log('')
  if (successCount > 0) {
    const overallSaved = totalInput > 0 ? Math.round(((totalInput - totalOutput) / totalInput) * 100) : 0
    console.log(
      `Total: ${successCount} file(s) converted, ${formatBytes(totalInput)} -> ${formatBytes(totalOutput)}, saved ${overallSaved}%`,
    )
  }
  if (failCount > 0) {
    console.log(`Failed: ${failCount} file(s)`)
    process.exitCode = 1
  }
}

main().catch((err) => {
  console.error('Fatal error:', err.message)
  process.exit(1)
})
