# BulkPicConv CLI

Command-line tool for batch image conversion via the [BulkPicConv](https://www.bulkpicconv.com) API.

## Features

- Batch convert multiple images to WebP, AVIF, JPEG, or PNG
- Glob pattern support (`*.jpg`, `images/**/*.png`)
- Progress bar for batch processing
- Per-file savings summary
- Recursive directory input
- `.bulkpicconvrc` JSON configuration
- Configurable timeout and transient retries
- Zero external dependencies (uses native Node.js APIs)

## Requirements

- Node.js 18+
- A BulkPicConv API key (`sk_...`)

## Installation

```bash
# Link globally from the project directory
cd cli/
npm link

# Or run directly with node
node ./cli/bin.js convert photo.jpg --format webp
```

## Usage

```
bulkpicconv convert <input...> [options]
```

### Options

| Option               | Description                                   | Default                       |
| -------------------- | --------------------------------------------- | ----------------------------- |
| `--format <fmt>`     | Output format: `webp`, `avif`, `jpeg`, `png`  | `webp`                        |
| `--quality <n>`      | Quality 1-100                                 | `75`                          |
| `--width <n>`        | Output width in pixels                        | -                             |
| `--height <n>`       | Output height in pixels                       | -                             |
| `-o, --output <dir>` | Output directory                              | Current directory             |
| `--api-key <key>`    | API key (or env: `BULKPICCONV_API_KEY`)       | -                             |
| `--base-url <url>`   | API base URL (or env: `BULKPICCONV_BASE_URL`) | `https://www.bulkpicconv.com` |
| `--timeout <ms>`     | Request timeout                               | `30000`                       |
| `--max-retries <n>`  | Maximum retries for transient failures        | `2`                           |
| `.bulkpicconvrc`     | JSON configuration; CLI flags override config | -                             |
| `-v, --version`      | Show version                                  | -                             |

### Recursive directory input

```bash
bulkpicconv convert ./images --format webp --output ./dist/
```

### Configuration file

Create `.bulkpicconvrc` in the current directory or a parent directory:

```json
{
  "format": "webp",
  "quality": 80,
  "output": "./dist",
  "timeout": 30000,
  "max-retries": 2
}
```

Command-line options override configuration values. Environment variables such as `BULKPICCONV_API_KEY` and `BULKPICCONV_BASE_URL` are used when no CLI or config value is present.

## Examples

### Basic conversion

```bash
bulkpicconv convert photo.jpg --format webp --quality 80
```

### Batch conversion with glob

```bash
# Convert all JPEGs in the current directory to AVIF
bulkpicconv convert *.jpg --format avif --quality 75

# Convert all PNGs recursively to WebP
bulkpicconv convert ./images/**/*.png --format webp -o ./optimized/
```

### Using environment variables

```bash
export BULKPICCONV_API_KEY=sk_your_api_key
bulkpicconv convert *.jpg --format webp --quality 80 --output ./dist/
```

### Resizing

```bash
bulkpicconv convert photo.jpg --format webp --width 1920 --height 1080 -o ./resized/
```

## Output

The CLI shows a progress bar during conversion and a per-file savings summary:

```
Converting  [##############################] 3/3  100%

  ✓ photo1.jpg -> ./dist/photo1.webp  245.0 KB -> 82.0 KB  saved 66%
  ✓ photo2.jpg -> ./dist/photo2.webp  1.2 MB -> 240.0 KB  saved 80%
  ✗ photo3.jpg - BulkPicConv API error (400): invalid_image

Total: 2 file(s) converted, 1.4 MB -> 322.0 KB, saved 76%
Failed: 1 file(s)
```

## License

MIT
